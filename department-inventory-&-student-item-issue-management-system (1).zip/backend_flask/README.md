# Department Inventory & Student Item Issue Management System
## Python Flask + SQLite Backend Documentation & Testing Guide
**Problem Statement #5: Department of Digital Forensics & InfoSec (DFIS)**  
*M.Sc. DFIS, Semester I Hardware Lab & Reusable Equipment Management*

---

### 1. Overview & Architecture

This backend implements a full REST API for the Department Inventory and Student Item Issue Management System using **Python 3 Flask** and a normalized **SQLite 3** database with foreign key integrity.

The frontend is built with React 19, TypeScript, and Vite. All `/api/*` network requests made from the browser are routed to the Flask server (port 5000) with development CORS and proxy support, preserving all existing design elements, typography, and UI layouts.

---

### 2. Database Schema (`schema.sql`)

1. **`items`**: Catalog of items distinguishing `INDIVIDUAL_ASSET` (e.g., STM32 development boards, logic analyzers) and `QUANTITY_REUSABLE` (e.g., USB cables, serial adapters). Tracks `total_quantity`, `available_quantity`, `issued_quantity`, `damaged_quantity`, `maintenance_quantity`, and `retired_quantity`.
2. **`individual_assets`**: Tracked assets with unique asset IDs (e.g., `DB-001` through `DB-010`), serial numbers, locations, conditions (`USABLE`, `DAMAGED`, `IN_MAINTENANCE`, `RETIRED`), and active borrower links.
3. **`students`**: Registered student records with name, unique enrolment number (e.g., `DFIS26001`), programme (`M.Sc. DFIS`), semester, contact info, active borrow count, and max borrowing limit (default: 3).
4. **`users`**: Authentication table with secure password hashes (PBKDF2 SHA-256 via `werkzeug.security`), role separation (`COORDINATOR`, `STUDENT`), and foreign key to `students(id)`.
5. **`sessions`**: Server-side token sessions with 24-hour expiry, validating coordinator vs student permissions.
6. **`issues`**: Loan records with issue date, due date (+15 calendar days), outstanding quantity, returned quantity, issuing staff, renewal count, and overdue tracking.
7. **`returns`**: Return records storing condition on receipt (`USABLE`, `DAMAGED`, etc.), partial vs full flag, receiving staff member, and inspection remarks.
8. **`renewals`**: Student renewal requests with original due date, proposed due date (+15 days), review status (`PENDING`, `APPROVED`, `REJECTED`), and approving staff notes.
9. **`stock_adjustments`**: Complete audit trail of all new stock additions, damage flags, repairs, and retirements with responsible staff and timestamps.
10. **`locations`**: Department laboratory rooms, cupboards, and safe storage locations.
11. **`system_settings`**: Configurable system simulation date (`2026-10-19`) for testing real-time 15-day rules and overdue calculations.

---

### 3. Business Rules Enforcement

- **Rule 1**: Items are issued only to registered students.
- **Rule 2 & 3**: Only available items in usable condition can be issued. If requested quantity exceeds available stock, the operation fails and explains why (e.g., *"Five adapters were requested, but only three are currently available"*).
- **Rule 4**: An individually tracked asset cannot be issued to more than one student simultaneously.
- **Rule 5**: The system automatically calculates the initial due date as **15 calendar days** after the issue date (e.g., 1 October 2026 -> 16 October 2026).
- **Rule 6 & 7**: Submitting a renewal request alone does not extend the due date. The due date remains unchanged until coordinator approval.
- **Rule 8**: Each approved renewal extends the due date by **15 calendar days from the existing due date** (e.g., 16 October 2026 -> 31 October 2026).
- **Rule 9 & 10**: Returned items become available for reissue only after physical receipt and condition inspection. Items returned in `DAMAGED` or `IN_MAINTENANCE` condition remain isolated until staff records a status change.
- **Rule 11**: Partial returns are supported with accurate outstanding balances.
- **Rule 12**: Every issue, return, renewal, and stock adjustment is logged with date, quantity, reason, and responsible user.

---

### 4. Running the System

#### Starting the Flask Backend:
```bash
python3 backend_flask/app.py
```
Server runs at `http://127.0.0.1:5000`.

#### Running Automated Backend Tests:
```bash
python3 backend_flask/test_backend.py
```
This test suite executes 14 unit and integration tests verifying all 12 mandatory rules, password hashing, student data privacy, and edge cases.

---

### 5. Pre-configured Credentials

| Role | Username / Identifier | Password | Access Scope |
| :--- | :--- | :--- | :--- |
| **Coordinator** | `coordinator@dfis.univ.edu` | `password123` | Full department management, approvals, stock |
| **Student (Rahul Sharma)** | `DFIS26001` | `password123` | View own loans, submit renewals |
| **Student (Ananya Iyer)** | `DFIS26002` | `password123` | View own loans, submit renewals |
| **Student (Priya Patel)** | `DFIS26003` | `password123` | View own loans, partial return history |

---

### 6. API Endpoints Reference

#### Authentication
- `POST /api/auth/login`: Authenticate with username/password, generates secure session token.
- `GET /api/auth/me`: Retrieves current user profile from bearer token.
- `POST /api/auth/logout`: Revokes active session token.

#### Inventory & Assets
- `GET /api/items`: List all catalog items with nested individual asset records.
- `GET /api/items/<id>`: Retrieve specific item with individual assets.
- `POST /api/items`: Create or update an inventory item.
- `GET /api/locations`: List department laboratory locations.

#### Item Issues & Returns
- `GET /api/issues`: List issue records with student and item details (filterable by `student_id`, `status`, `overdue`).
- `POST /api/issue`: Issue item with 15-day rule enforcement.
- `GET /api/returns`: List return transaction records.
- `POST /api/return`: Record partial or complete return with condition check.

#### Renewals
- `GET /api/renewals`: List all renewal requests.
- `POST /api/renew/request`: Student renewal request (keeps due date unchanged).
- `POST /api/renew/review`: Coordinator approval/rejection (+15 days extension).

#### System & Audit
- `GET /api/dashboard`: Summary counts, overdue alerts, recent loans.
- `GET /api/system/date`: Get current simulation date.
- `POST /api/system/date`: Update simulation date.
- `POST /api/system/reset`: Reset database to initial M.Sc. DFIS demonstration state.
- `GET /api/stock-adjustments`: Audit trail of inventory updates.
- `POST /api/stock-adjustments`: Record new stock, damage flag, maintenance, or retirement.
- `GET /api/student/me/issues`: Authenticated student's active and returned items.
- `GET /api/student/me/renewals`: Authenticated student's renewal requests.
- `GET /api/student/me/returns`: Authenticated student's return records.
