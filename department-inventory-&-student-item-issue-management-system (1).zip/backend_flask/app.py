"""
Department Inventory and Student Item Issue Management System
Backend: Python 3 Flask + SQLite
Problem Statement #5: Department of Digital Forensics & InfoSec (DFIS)
M.Sc. DFIS, Semester I
"""

import os
import sqlite3
import secrets
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, request, jsonify, g
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'msc_dfis_inventory_secret_key_2026')

DB_FILE = os.path.join(os.path.dirname(__file__), 'inventory.db')
SCHEMA_FILE = os.path.join(os.path.dirname(__file__), 'schema.sql')

DEFAULT_SYSTEM_DATE = '2026-10-19'

# --- CORS & RESPONSE HEADERS ---
@app.after_request
def add_cors_and_headers(response):
    origin = request.headers.get('Origin')
    if origin:
        response.headers['Access-Control-Allow-Origin'] = origin
        response.headers['Access-Control-Allow-Credentials'] = 'true'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Requested-With, X-Session-Token'
        response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS, PATCH'
    return response

@app.before_request
def handle_options():
    if request.method == 'OPTIONS':
        resp = app.make_default_options_response()
        origin = request.headers.get('Origin')
        if origin:
            resp.headers['Access-Control-Allow-Origin'] = origin
            resp.headers['Access-Control-Allow-Credentials'] = 'true'
            resp.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Requested-With, X-Session-Token'
            resp.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS, PATCH'
        return resp

# --- DATABASE CONNECTION & TRANSACTION HELPERS ---
def get_db():
    conn = sqlite3.connect(DB_FILE, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

def get_current_system_date(conn):
    cursor = conn.cursor()
    cursor.execute("SELECT setting_value FROM system_settings WHERE setting_key = 'system_date'")
    row = cursor.fetchone()
    if row and row['setting_value']:
        return row['setting_value']
    return DEFAULT_SYSTEM_DATE

def set_current_system_date(conn, new_date):
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO system_settings (setting_key, setting_value)
        VALUES ('system_date', ?)
        ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value
    """, (new_date,))

def calculate_due_date(issue_date_str, days=15):
    """Rule 5 & Rule 8: Calendar days calculation"""
    dt = datetime.strptime(issue_date_str, '%Y-%m-%d')
    due = dt + timedelta(days=days)
    return due.strftime('%Y-%m-%d')

# --- AUTHENTICATION & RBAC DECORATORS ---
def get_bearer_token():
    auth_header = request.headers.get('Authorization', '')
    if auth_header.startswith('Bearer '):
        return auth_header[7:].strip()
    return request.headers.get('X-Session-Token', '').strip()

def get_session_user(conn):
    token = get_bearer_token()
    if not token:
        return None
    cursor = conn.cursor()
    cursor.execute("""
        SELECT s.token, s.user_id, s.role, s.student_id, s.expires_at,
               u.username, u.name, u.email
        FROM sessions s
        JOIN users u ON s.user_id = u.id
        WHERE s.token = ?
    """, (token,))
    row = cursor.fetchone()
    if not row:
        return None
    
    expires_at = datetime.fromisoformat(row['expires_at'])
    if datetime.utcnow() > expires_at:
        cursor.execute("DELETE FROM sessions WHERE token = ?", (token,))
        conn.commit()
        return None
    
    return dict(row)

def require_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        with get_db() as conn:
            user = get_session_user(conn)
            if not user:
                return jsonify({'success': False, 'message': 'Unauthenticated: Valid session token required.'}), 401
            g.user = user
        return f(*args, **kwargs)
    return decorated

def require_coordinator(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        with get_db() as conn:
            user = get_session_user(conn)
            if not user:
                return jsonify({'success': False, 'message': 'Unauthenticated: Valid session token required.'}), 401
            if user['role'] != 'COORDINATOR':
                return jsonify({'success': False, 'message': 'Forbidden: Coordinator privileges required.'}), 403
            g.user = user
        return f(*args, **kwargs)
    return decorated

def require_student(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        with get_db() as conn:
            user = get_session_user(conn)
            if not user:
                return jsonify({'success': False, 'message': 'Unauthenticated: Valid session token required.'}), 401
            if user['role'] != 'STUDENT' or not user['student_id']:
                return jsonify({'success': False, 'message': 'Forbidden: Valid student session required.'}), 403
            g.user = user
        return f(*args, **kwargs)
    return decorated

# --- DATABASE SEEDING ---
def seed_initial_data(conn):
    cursor = conn.cursor()
    # 1. System date
    set_current_system_date(conn, DEFAULT_SYSTEM_DATE)

    # 2. Locations
    locations = [
        ('loc-1', 'DFIS', 'Cyber Lab 102', '102', 'Cupboard B-1'),
        ('loc-2', 'DFIS', 'Embedded & Forensics Lab', '103', 'Cupboard A-2'),
        ('loc-3', 'DFIS', 'Hardware Lab', '104', 'Shelf C'),
        ('loc-4', 'DFIS', 'Department Secure Vault', '101', 'Forensics Safe')
    ]
    for loc in locations:
        cursor.execute("""
            INSERT OR IGNORE INTO locations (id, department, laboratory, room, cupboard)
            VALUES (?, ?, ?, ?, ?)
        """, loc)

    # 3. Students
    students = [
        ('stu-01', 'Rahul Sharma', 'DFIS26001', 'M.Sc. DFIS', 'Semester I', 'rahul.sharma@univ.edu', '+91 98765 43210', 2, 3),
        ('stu-02', 'Ananya Iyer', 'DFIS26002', 'M.Sc. DFIS', 'Semester I', 'ananya.iyer@univ.edu', '+91 98765 43211', 1, 3),
        ('stu-03', 'Priya Patel', 'DFIS26003', 'M.Sc. DFIS', 'Semester I', 'priya.patel@univ.edu', '+91 98765 43212', 1, 3),
        ('stu-04', 'Vikramaditya Verma', 'DFIS26004', 'M.Sc. DFIS', 'Semester I', 'vikram.verma@univ.edu', '+91 98765 43213', 0, 3),
        ('stu-05', 'Rohit Deshmukh', 'DFIS26005', 'M.Sc. DFIS', 'Semester I', 'rohit.deshmukh@univ.edu', '+91 98765 43214', 0, 3)
    ]
    for stu in students:
        cursor.execute("""
            INSERT OR IGNORE INTO students (id, name, enrolment_number, programme, semester, email, phone, active_borrow_count, max_borrow_limit)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, stu)

    # 4. Users (Secure hashed passwords)
    common_pwd = generate_password_hash('password123')
    users = [
        ('user-coord-01', 'coordinator@dfis.univ.edu', common_pwd, 'COORDINATOR', 'Dr. S. K. Mehta (Coordinator)', 'coordinator@dfis.univ.edu', None, '2026-09-01'),
        ('user-stu-01', 'DFIS26001', common_pwd, 'STUDENT', 'Rahul Sharma', 'rahul.sharma@univ.edu', 'stu-01', '2026-09-01'),
        ('user-stu-02', 'DFIS26002', common_pwd, 'STUDENT', 'Ananya Iyer', 'ananya.iyer@univ.edu', 'stu-02', '2026-09-01'),
        ('user-stu-03', 'DFIS26003', common_pwd, 'STUDENT', 'Priya Patel', 'priya.patel@univ.edu', 'stu-03', '2026-09-01'),
        ('user-stu-04', 'DFIS26004', common_pwd, 'STUDENT', 'Vikramaditya Verma', 'vikram.verma@univ.edu', 'stu-04', '2026-09-01'),
        ('user-stu-05', 'DFIS26005', common_pwd, 'STUDENT', 'Rohit Deshmukh', 'rohit.deshmukh@univ.edu', 'stu-05', '2026-09-01'),
    ]
    for u in users:
        cursor.execute("""
            INSERT OR IGNORE INTO users (id, username, password_hash, role, name, email, student_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, u)

    # 5. Inventory Items
    # 5a. 10 Development Boards (INDIVIDUAL_ASSET)
    cursor.execute("""
        INSERT OR IGNORE INTO items (id, item_code, name, category, description, make_model, tracking_type, total_quantity, available_quantity, issued_quantity, damaged_quantity, maintenance_quantity, retired_quantity, location, created_at, updated_at)
        VALUES ('item-dev-board-01', 'DB-STM32-ARM', 'STM32 ARM Cortex Development Board', 'Development Boards',
                'Hardware security & embedded forensics dev boards with ARM Cortex-M4 microcontroller.',
                'STMicroelectronics NUCLEO-F446RE', 'INDIVIDUAL_ASSET', 10, 9, 1, 0, 0, 0,
                'Cyber Lab 102 - Cupboard B-1', '2026-09-15', '2026-10-01')
    """)
    for i in range(1, 11):
        num_str = str(i).zfill(3)
        asset_id = f"DB-{num_str}"
        is_issued = (i == 1) # DB-001 issued to Rahul Sharma
        cursor.execute("""
            INSERT OR IGNORE INTO individual_assets (id, item_id, asset_id, serial_number, location, condition, status, current_student_id, current_issue_id)
            VALUES (?, 'item-dev-board-01', ?, ?, 'Cyber Lab 102 - Cupboard B-1', 'USABLE', ?, ?, ?)
        """, (f"asset-db-{i}", asset_id, f"SN-STM32-2026-{num_str}", 'ISSUED' if is_issued else 'AVAILABLE', 'stu-01' if is_issued else None, 'issue-01' if is_issued else None))

    # 5b. 20 Reusable USB Cables (QUANTITY_REUSABLE)
    cursor.execute("""
        INSERT OR IGNORE INTO items (id, item_code, name, category, description, make_model, tracking_type, total_quantity, available_quantity, issued_quantity, damaged_quantity, maintenance_quantity, retired_quantity, location, created_at, updated_at)
        VALUES ('item-usb-cable-01', 'CBL-USB-C2M', 'Reusable USB-C to USB-A Cable (2m)', 'Cables & Adapters',
                'High-speed braided data and debugging cables for embedded targets.',
                'Anker PowerLine+ 2.0m', 'QUANTITY_REUSABLE', 20, 18, 2, 0, 0, 0,
                'Hardware Lab 104 - Shelf C', '2026-09-15', '2026-10-01')
    """)

    # 5c. 5 Logic Analyzers (INDIVIDUAL_ASSET)
    cursor.execute("""
        INSERT OR IGNORE INTO items (id, item_code, name, category, description, make_model, tracking_type, total_quantity, available_quantity, issued_quantity, damaged_quantity, maintenance_quantity, retired_quantity, location, created_at, updated_at)
        VALUES ('item-logic-analyzer-01', 'LA-24MHZ-8CH', 'USB 8-Channel Logic Analyzer 24MHz', 'Test & Measurement',
                'Hardware protocol sniffing analyzer for I2C, SPI, and UART digital forensics.',
                'Saleae Compatible 24MHz Logic Pro', 'INDIVIDUAL_ASSET', 5, 4, 1, 0, 0, 0,
                'Embedded & Forensics Lab - Cupboard A-2', '2026-09-15', '2026-10-05')
    """)
    for i in range(1, 6):
        aid = f"LA-00{i}"
        is_iss = (i == 2) # LA-002 issued to Ananya Iyer
        cursor.execute("""
            INSERT OR IGNORE INTO individual_assets (id, item_id, asset_id, serial_number, location, condition, status, current_student_id, current_issue_id)
            VALUES (?, 'item-logic-analyzer-01', ?, ?, 'Cupboard A-2', 'USABLE', ?, ?, ?)
        """, (f"la-{i}", aid, f"SN-LA-2026-00{i}", 'ISSUED' if is_iss else 'AVAILABLE', 'stu-02' if is_iss else None, 'issue-03' if is_iss else None))

    # 5d. 15 USB-TTL Serial Converters (QUANTITY_REUSABLE)
    cursor.execute("""
        INSERT OR IGNORE INTO items (id, item_code, name, category, description, make_model, tracking_type, total_quantity, available_quantity, issued_quantity, damaged_quantity, maintenance_quantity, retired_quantity, location, created_at, updated_at)
        VALUES ('item-serial-adapter-01', 'ADP-FTDI-UART', 'USB-TTL FTDI Serial Converter', 'Cables & Adapters',
                '3.3V/5V FT232RL USB to TTL serial transceiver module for serial console debugging.',
                'FTDI Chip FT232RL', 'QUANTITY_REUSABLE', 15, 14, 1, 0, 0, 0,
                'Hardware Lab 104 - Shelf C', '2026-09-15', '2026-10-02')
    """)

    # 5e. 8 YubiKeys (INDIVIDUAL_ASSET)
    cursor.execute("""
        INSERT OR IGNORE INTO items (id, item_code, name, category, description, make_model, tracking_type, total_quantity, available_quantity, issued_quantity, damaged_quantity, maintenance_quantity, retired_quantity, location, created_at, updated_at)
        VALUES ('item-yubikey-01', 'SEC-YUBIKEY-5NFC', 'YubiKey 5 NFC Hardware Token', 'Security Tokens',
                'FIDO2 / U2F cryptographic hardware security key for biometric and smart card labs.',
                'Yubico 5 Series NFC', 'INDIVIDUAL_ASSET', 8, 7, 0, 1, 0, 0,
                'Department Secure Vault - Forensics Safe', '2026-09-15', '2026-09-25')
    """)
    for i in range(1, 9):
        aid = f"YK-00{i}"
        is_dmg = (i == 3)
        cursor.execute("""
            INSERT OR IGNORE INTO individual_assets (id, item_id, asset_id, serial_number, location, condition, status, current_student_id, current_issue_id)
            VALUES (?, 'item-yubikey-01', ?, ?, 'Vault 101', ?, ?, NULL, NULL)
        """, (f"yk-{i}", aid, f"SN-YK-2026-00{i}", 'DAMAGED' if is_dmg else 'USABLE', 'IN_MAINTENANCE' if is_dmg else 'AVAILABLE'))

    # 6. Preloaded Issues (Problem statement prompt example)
    # Issue 1: Rahul Sharma issued 1 dev board (DB-001) on 1 Oct 2026 due 16 Oct 2026
    cursor.execute("""
        INSERT OR IGNORE INTO issues (id, issue_number, student_id, item_id, asset_id, quantity, outstanding_quantity, returned_quantity, purpose, issue_date, due_date, issuing_staff, status, renewal_count, last_renewal_date, acknowledgement_generated, notes)
        VALUES ('issue-01', 'ISS-2026-1001', 'stu-01', 'item-dev-board-01', 'DB-001', 1, 1, 0,
                'Embedded Firmware Forensics Lab 1 Assignment', '2026-10-01', '2026-10-16',
                'Dr. S. K. Mehta (Coordinator)', 'ACTIVE', 0, NULL, 1, 'Issued in pristine condition for M.Sc. DFIS Sem I lab work.')
    """)

    # Issue 2: Rahul Sharma issued 2 USB cables on 1 Oct 2026 due 16 Oct 2026
    cursor.execute("""
        INSERT OR IGNORE INTO issues (id, issue_number, student_id, item_id, asset_id, quantity, outstanding_quantity, returned_quantity, purpose, issue_date, due_date, issuing_staff, status, renewal_count, last_renewal_date, acknowledgement_generated, notes)
        VALUES ('issue-02', 'ISS-2026-1002', 'stu-01', 'item-usb-cable-01', NULL, 2, 2, 0,
                'Board interconnect & debugging power link', '2026-10-01', '2026-10-16',
                'Dr. S. K. Mehta (Coordinator)', 'ACTIVE', 0, NULL, 1, '2 braided cables issued together with dev board.')
    """)

    # Issue 3: Ananya Iyer issued 1 Logic Analyzer (LA-002) on 5 Oct 2026 due 20 Oct 2026
    cursor.execute("""
        INSERT OR IGNORE INTO issues (id, issue_number, student_id, item_id, asset_id, quantity, outstanding_quantity, returned_quantity, purpose, issue_date, due_date, issuing_staff, status, renewal_count, last_renewal_date, acknowledgement_generated, notes)
        VALUES ('issue-03', 'ISS-2026-1003', 'stu-02', 'item-logic-analyzer-01', 'LA-002', 1, 1, 0,
                'SPI Bus packet capture analysis project', '2026-10-05', '2026-10-20',
                'Dr. S. K. Mehta (Coordinator)', 'ACTIVE', 0, NULL, 1, NULL)
    """)

    # Issue 4: Priya Patel issued 3 Serial Converters on 20 Sep 2026, returned 2 on 2 Oct 2026, 1 remaining outstanding
    cursor.execute("""
        INSERT OR IGNORE INTO issues (id, issue_number, student_id, item_id, asset_id, quantity, outstanding_quantity, returned_quantity, purpose, issue_date, due_date, issuing_staff, status, renewal_count, last_renewal_date, acknowledgement_generated, notes)
        VALUES ('issue-04', 'ISS-2026-1004', 'stu-03', 'item-serial-adapter-01', NULL, 3, 1, 2,
                'Multi-port serial communication test harness', '2026-09-20', '2026-10-05',
                'Dr. S. K. Mehta (Coordinator)', 'PARTIALLY_RETURNED', 0, NULL, 1, '2 returned on 2 Oct; 1 adapter still outstanding.')
    """)

    # 7. Past Returns (Priya Patel partial return)
    cursor.execute("""
        INSERT OR IGNORE INTO returns (id, issue_id, student_id, item_id, asset_id, quantity_returned, return_date, condition_on_return, receiving_staff, remarks, is_partial)
        VALUES ('ret-01', 'issue-04', 'stu-03', 'item-serial-adapter-01', NULL, 2, '2026-10-02',
                'USABLE', 'Dr. S. K. Mehta', 'Partial return of 2 adapters in clean condition. 1 remaining outstanding.', 1)
    """)

    # 8. Pending Renewal (Rahul Sharma cables issue-02)
    cursor.execute("""
        INSERT OR IGNORE INTO renewals (id, issue_id, student_id, request_date, status, original_due_date, proposed_due_date, revised_due_date, approving_staff, remarks)
        VALUES ('ren-01', 'issue-02', 'stu-01', '2026-10-14', 'PENDING', '2026-10-16', '2026-10-31',
                NULL, NULL, 'Require additional 15 days to finish final firmware verification in Lab 102.')
    """)

    # 9. Stock Adjustments Audit Trail
    cursor.execute("""
        INSERT OR IGNORE INTO stock_adjustments (id, item_id, asset_id, adjustment_type, quantity, reason, responsible_user, timestamp)
        VALUES ('adj-01', 'item-dev-board-01', NULL, 'NEW_STOCK', 10,
                'Initial procurement for M.Sc. DFIS Semester I Embedded Forensics Lab.',
                'Dr. S. K. Mehta (Coordinator)', '2026-09-15 10:30')
    """)
    cursor.execute("""
        INSERT OR IGNORE INTO stock_adjustments (id, item_id, asset_id, adjustment_type, quantity, reason, responsible_user, timestamp)
        VALUES ('adj-02', 'item-usb-cable-01', NULL, 'NEW_STOCK', 20,
                'Department stock purchase - 20 reusable cables.',
                'Dr. S. K. Mehta (Coordinator)', '2026-09-15 11:00')
    """)
    cursor.execute("""
        INSERT OR IGNORE INTO stock_adjustments (id, item_id, asset_id, adjustment_type, quantity, reason, responsible_user, timestamp)
        VALUES ('adj-03', 'item-yubikey-01', 'YK-003', 'DAMAGE_FLAG', 1,
                'NFC chip failure discovered during pre-session audit. Marked for maintenance.',
                'Dr. S. K. Mehta (Coordinator)', '2026-09-25 14:15')
    """)

    conn.commit()

def init_db():
    with open(SCHEMA_FILE, 'r') as f:
        schema = f.read()
    with get_db() as conn:
        conn.executescript(schema)
        # Check if items exist; if not, seed initial M.Sc. DFIS demonstration data
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM items")
        if cursor.fetchone()[0] == 0:
            seed_initial_data(conn)

# --- SERIALIZATION HELPERS ---
def format_item(item_row, individual_assets=None):
    res = {
        'id': item_row['id'],
        'itemCode': item_row['item_code'],
        'name': item_row['name'],
        'category': item_row['category'],
        'description': item_row['description'] or '',
        'makeModel': item_row['make_model'] or '',
        'trackingType': item_row['tracking_type'],
        'totalQuantity': item_row['total_quantity'],
        'availableQuantity': item_row['available_quantity'],
        'issuedQuantity': item_row['issued_quantity'],
        'damagedQuantity': item_row['damaged_quantity'],
        'maintenanceQuantity': item_row['maintenance_quantity'],
        'retiredQuantity': item_row['retired_quantity'],
        'location': item_row['location'],
        'createdAt': item_row['created_at'],
        'updatedAt': item_row['updated_at'],
    }
    if individual_assets is not None:
        res['individualAssets'] = [
            {
                'id': a['id'],
                'itemId': a['item_id'],
                'assetId': a['asset_id'],
                'serialNumber': a['serial_number'] or '',
                'location': a['location'],
                'condition': a['condition'],
                'status': a['status'],
                'currentStudentId': a['current_student_id'],
                'currentIssueId': a['current_issue_id'],
            } for a in individual_assets
        ]
    return res

def format_student(student_row):
    return {
        'id': student_row['id'],
        'name': student_row['name'],
        'enrolmentNumber': student_row['enrolment_number'],
        'programme': student_row['programme'],
        'semester': student_row['semester'],
        'email': student_row['email'] or '',
        'phone': student_row['phone'] or '',
        'activeBorrowCount': student_row['active_borrow_count'],
        'maxBorrowLimit': student_row['max_borrow_limit'],
    }

def format_issue(issue_row, system_date):
    due_date = issue_row['due_date']
    outstanding = issue_row['outstanding_quantity']
    is_over = outstanding > 0 and system_date > due_date
    status = 'OVERDUE' if is_over else issue_row['status']
    return {
        'id': issue_row['id'],
        'issueNumber': issue_row['issue_number'],
        'studentId': issue_row['student_id'],
        'studentName': issue_row['student_name'],
        'studentEnrolment': issue_row['student_enrolment'],
        'itemId': issue_row['item_id'],
        'itemName': issue_row['item_name'],
        'itemCode': issue_row['item_code'],
        'trackingType': issue_row['tracking_type'],
        'assetId': issue_row['asset_id'],
        'quantity': issue_row['quantity'],
        'outstandingQuantity': issue_row['outstanding_quantity'],
        'returnedQuantity': issue_row['returned_quantity'],
        'purpose': issue_row['purpose'],
        'issueDate': issue_row['issue_date'],
        'dueDate': issue_row['due_date'],
        'issuingStaff': issue_row['issuing_staff'],
        'status': status,
        'renewalCount': issue_row['renewal_count'],
        'lastRenewalDate': issue_row['last_renewal_date'],
        'acknowledgementGenerated': bool(issue_row['acknowledgement_generated']),
        'notes': issue_row['notes'] or '',
    }

def format_return(ret_row):
    return {
        'id': ret_row['id'],
        'issueId': ret_row['issue_id'],
        'studentId': ret_row['student_id'],
        'studentName': ret_row['student_name'],
        'itemId': ret_row['item_id'],
        'itemName': ret_row['item_name'],
        'assetId': ret_row['asset_id'],
        'quantityReturned': ret_row['quantity_returned'],
        'returnDate': ret_row['return_date'],
        'conditionOnReturn': ret_row['condition_on_return'],
        'receivingStaff': ret_row['receiving_staff'],
        'remarks': ret_row['remarks'] or '',
        'isPartial': bool(ret_row['is_partial']),
    }

def format_renewal(ren_row):
    return {
        'id': ren_row['id'],
        'issueId': ren_row['issue_id'],
        'studentId': ren_row['student_id'],
        'studentName': ren_row['student_name'],
        'studentEnrolment': ren_row['student_enrolment'],
        'itemName': ren_row['item_name'],
        'assetId': ren_row['asset_id'],
        'requestDate': ren_row['request_date'],
        'status': ren_row['status'],
        'originalDueDate': ren_row['original_due_date'],
        'proposedDueDate': ren_row['proposed_due_date'],
        'revisedDueDate': ren_row['revised_due_date'],
        'approvingStaff': ren_row['approving_staff'],
        'remarks': ren_row['remarks'] or '',
        'requestedByStudentId': ren_row['student_id'],
    }

def format_adjustment(adj_row):
    return {
        'id': adj_row['id'],
        'itemId': adj_row['item_id'],
        'itemName': adj_row['item_name'],
        'assetId': adj_row['asset_id'],
        'adjustmentType': adj_row['adjustment_type'],
        'quantity': adj_row['quantity'],
        'reason': adj_row['reason'],
        'responsibleUser': adj_row['responsible_user'],
        'timestamp': adj_row['timestamp'],
    }


# ============================================================================
# API ROUTES
# ============================================================================

# --- 1. AUTHENTICATION & SESSION ENDPOINTS ---

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json or {}
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    role_hint = data.get('role')
    student_id_hint = data.get('studentId')

    with get_db() as conn:
        cursor = conn.cursor()
        user = None

        if username:
            # Query by username or student enrolment number or email
            cursor.execute("""
                SELECT * FROM users
                WHERE username = ? OR email = ?
            """, (username, username))
            user = cursor.fetchone()
        
        # If studentId passed from demo student selector
        if not user and student_id_hint and role_hint == 'STUDENT':
            cursor.execute("SELECT * FROM users WHERE student_id = ?", (student_id_hint,))
            user = cursor.fetchone()

        # If coordinator email default
        if not user and username.lower() == 'coordinator@dfis.univ.edu':
            cursor.execute("SELECT * FROM users WHERE role = 'COORDINATOR' LIMIT 1")
            user = cursor.fetchone()

        if not user:
            return jsonify({'success': False, 'message': 'Invalid username or credentials.'}), 401

        # Check password hash (allow default 'password123' check)
        if not check_password_hash(user['password_hash'], password) and password != 'password123':
            return jsonify({'success': False, 'message': 'Invalid password.'}), 401

        # Create session token
        token = secrets.token_hex(32)
        expires_at = (datetime.utcnow() + timedelta(days=1)).isoformat()
        cursor.execute("""
            INSERT INTO sessions (token, user_id, role, student_id, expires_at, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (token, user['id'], user['role'], user['student_id'], expires_at, datetime.utcnow().isoformat()))
        conn.commit()

        student_info = None
        if user['student_id']:
            cursor.execute("SELECT * FROM students WHERE id = ?", (user['student_id'],))
            s_row = cursor.fetchone()
            if s_row:
                student_info = format_student(s_row)

        return jsonify({
            'success': True,
            'token': token,
            'user': {
                'id': user['id'],
                'username': user['username'],
                'role': user['role'],
                'name': user['name'],
                'email': user['email'] or '',
                'studentId': user['student_id'],
                'student': student_info
            }
        })

@app.route('/api/auth/me', methods=['GET'])
def get_current_user():
    with get_db() as conn:
        user = get_session_user(conn)
        if not user:
            return jsonify({'success': False, 'user': None}), 401

        cursor = conn.cursor()
        student_info = None
        if user['student_id']:
            cursor.execute("SELECT * FROM students WHERE id = ?", (user['student_id'],))
            s_row = cursor.fetchone()
            if s_row:
                student_info = format_student(s_row)

        return jsonify({
            'success': True,
            'user': {
                'id': user['user_id'],
                'username': user['username'],
                'role': user['role'],
                'name': user['name'],
                'email': user['email'] or '',
                'studentId': user['student_id'],
                'student': student_info
            }
        })

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    token = get_bearer_token()
    if token:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM sessions WHERE token = ?", (token,))
            conn.commit()
    return jsonify({'success': True, 'message': 'Logged out successfully.'})


# --- 2. SYSTEM DATE & RESET ENDPOINTS ---

@app.route('/api/system/date', methods=['GET'])
def get_system_date():
    with get_db() as conn:
        current_date = get_current_system_date(conn)
        return jsonify({'systemDate': current_date})

@app.route('/api/system/date', methods=['POST'])
def update_system_date():
    data = request.json or {}
    new_date = data.get('systemDate')
    if not new_date:
        return jsonify({'success': False, 'message': 'systemDate is required.'}), 400
    try:
        datetime.strptime(new_date, '%Y-%m-%d')
    except ValueError:
        return jsonify({'success': False, 'message': 'Invalid date format. Expected YYYY-MM-DD.'}), 400

    with get_db() as conn:
        set_current_system_date(conn, new_date)
        conn.commit()
        return jsonify({'success': True, 'systemDate': new_date})

@app.route('/api/system/reset', methods=['POST'])
def reset_system():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("DROP TABLE IF EXISTS stock_adjustments")
        cursor.execute("DROP TABLE IF EXISTS renewals")
        cursor.execute("DROP TABLE IF EXISTS returns")
        cursor.execute("DROP TABLE IF EXISTS issues")
        cursor.execute("DROP TABLE IF EXISTS individual_assets")
        cursor.execute("DROP TABLE IF EXISTS items")
        cursor.execute("DROP TABLE IF EXISTS students")
        cursor.execute("DROP TABLE IF EXISTS sessions")
        cursor.execute("DROP TABLE IF EXISTS users")
        cursor.execute("DROP TABLE IF EXISTS locations")
        cursor.execute("DROP TABLE IF EXISTS system_settings")
        conn.commit()
    
    init_db()
    return jsonify({'success': True, 'message': 'System database successfully reset to M.Sc. DFIS initial state.'})


# --- 3. DASHBOARD METRICS ---

@app.route('/api/dashboard', methods=['GET'])
def get_dashboard_summary():
    with get_db() as conn:
        system_date = get_current_system_date(conn)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT 
                COALESCE(SUM(total_quantity), 0) as total_units,
                COALESCE(SUM(available_quantity), 0) as available_units,
                COALESCE(SUM(issued_quantity), 0) as issued_units,
                COALESCE(SUM(damaged_quantity + maintenance_quantity), 0) as damaged_or_maint_units
            FROM items
        """)
        totals = cursor.fetchone()

        cursor.execute("""
            SELECT COUNT(*) FROM issues 
            WHERE outstanding_quantity > 0 AND due_date < ?
        """, (system_date,))
        overdue_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM renewals WHERE status = 'PENDING'")
        pending_renewals = cursor.fetchone()[0]

        # Recent activities (issues and returns)
        cursor.execute("""
            SELECT i.*, s.name as student_name, s.enrolment_number as student_enrolment,
                   itm.name as item_name, itm.item_code, itm.tracking_type
            FROM issues i
            JOIN students s ON i.student_id = s.id
            JOIN items itm ON i.item_id = itm.id
            ORDER BY i.issue_date DESC LIMIT 5
        """)
        recent_issues = [format_issue(row, system_date) for row in cursor.fetchall()]

        return jsonify({
            'total_units': totals['total_units'],
            'available_units': totals['available_units'],
            'issued_units': totals['issued_units'],
            'damaged_units': totals['damaged_or_maint_units'],
            'overdue_count': overdue_count,
            'pending_renewals': pending_renewals,
            'systemDate': system_date,
            'recentIssues': recent_issues
        })


# --- 4. INVENTORY ITEMS & ASSETS ---

@app.route('/api/items', methods=['GET'])
def list_items():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM items ORDER BY name ASC")
        item_rows = cursor.fetchall()
        
        # Load individual assets grouped by item_id
        cursor.execute("SELECT * FROM individual_assets ORDER BY asset_id ASC")
        assets = cursor.fetchall()
        asset_map = {}
        for a in assets:
            asset_map.setdefault(a['item_id'], []).append(a)

        result = [format_item(r, asset_map.get(r['id'], [])) for r in item_rows]
        return jsonify(result)

@app.route('/api/items/<item_id>', methods=['GET'])
def get_item(item_id):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM items WHERE id = ?", (item_id,))
        item = cursor.fetchone()
        if not item:
            return jsonify({'success': False, 'message': 'Item not found.'}), 404

        cursor.execute("SELECT * FROM individual_assets WHERE item_id = ? ORDER BY asset_id ASC", (item_id,))
        assets = cursor.fetchall()
        return jsonify(format_item(item, assets))

@app.route('/api/items', methods=['POST'])
def save_item():
    data = request.json or {}
    item_id = data.get('id')
    name = data.get('name', '').strip()
    item_code = data.get('itemCode', '').strip()
    category = data.get('category', 'General Equipment')
    description = data.get('description', '')
    make_model = data.get('makeModel', '')
    tracking_type = data.get('trackingType', 'QUANTITY_REUSABLE')
    total_qty = int(data.get('totalQuantity', 1))
    location = data.get('location', 'Cyber Lab 102')

    if not name or not item_code:
        return jsonify({'success': False, 'message': 'Item name and code are required.'}), 400

    with get_db() as conn:
        system_date = get_current_system_date(conn)
        cursor = conn.cursor()

        if item_id:
            # Edit existing
            cursor.execute("SELECT * FROM items WHERE id = ?", (item_id,))
            existing = cursor.fetchone()
            if not existing:
                return jsonify({'success': False, 'message': 'Item not found.'}), 404

            cursor.execute("""
                UPDATE items
                SET name = ?, category = ?, description = ?, make_model = ?, location = ?, updated_at = ?
                WHERE id = ?
            """, (name, category, description, make_model, location, system_date, item_id))
            conn.commit()

            cursor.execute("SELECT * FROM items WHERE id = ?", (item_id,))
            updated_item = cursor.fetchone()
            cursor.execute("SELECT * FROM individual_assets WHERE item_id = ? ORDER BY asset_id ASC", (item_id,))
            assets = cursor.fetchall()

            return jsonify({
                'success': True,
                'message': f'Item "{name}" updated successfully.',
                'item': format_item(updated_item, assets)
            })
        else:
            # Check unique item code
            cursor.execute("SELECT id FROM items WHERE item_code = ?", (item_code,))
            if cursor.fetchone():
                return jsonify({'success': False, 'message': f'Item code "{item_code}" already exists.'}), 400

            new_id = f"item-{int(datetime.now().timestamp() * 1000)}"
            cursor.execute("""
                INSERT INTO items (id, item_code, name, category, description, make_model, tracking_type, total_quantity, available_quantity, issued_quantity, damaged_quantity, maintenance_quantity, retired_quantity, location, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, 0, ?, ?, ?)
            """, (new_id, item_code, name, category, description, make_model, tracking_type, total_qty, total_qty, location, system_date, system_date))

            # Auto-generate individual assets if INDIVIDUAL_ASSET
            if tracking_type == 'INDIVIDUAL_ASSET':
                prefix = item_code.split('-')[0] if '-' in item_code else 'AST'
                for i in range(1, total_qty + 1):
                    asset_id = f"{prefix}-{str(i).zfill(3)}"
                    cursor.execute("""
                        INSERT INTO individual_assets (id, item_id, asset_id, location, condition, status)
                        VALUES (?, ?, ?, ?, 'USABLE', 'AVAILABLE')
                    """, (f"asset-{new_id}-{i}", new_id, asset_id, location))

            # Log audit trail
            cursor.execute("""
                INSERT INTO stock_adjustments (id, item_id, adjustment_type, quantity, reason, responsible_user, timestamp)
                VALUES (?, ?, 'NEW_STOCK', ?, 'Initial item catalog creation', 'Dr. S. K. Mehta (Coordinator)', ?)
            """, (f"adj-{int(datetime.now().timestamp() * 1000)}", new_id, total_qty, f"{system_date} 10:00"))

            conn.commit()

            cursor.execute("SELECT * FROM items WHERE id = ?", (new_id,))
            created_item = cursor.fetchone()
            cursor.execute("SELECT * FROM individual_assets WHERE item_id = ? ORDER BY asset_id ASC", (new_id,))
            assets = cursor.fetchall()

            return jsonify({
                'success': True,
                'message': f'Item "{name}" created with code {item_code}.',
                'item': format_item(created_item, assets)
            })


# --- 5. STUDENTS ENDPOINTS ---

@app.route('/api/students', methods=['GET'])
def list_students():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM students ORDER BY name ASC")
        students = [format_student(r) for r in cursor.fetchall()]
        return jsonify(students)

@app.route('/api/students/<student_id>', methods=['GET'])
def get_student(student_id):
    with get_db() as conn:
        system_date = get_current_system_date(conn)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM students WHERE id = ?", (student_id,))
        stu = cursor.fetchone()
        if not stu:
            return jsonify({'success': False, 'message': 'Student not found.'}), 404

        # Fetch student's loan history
        cursor.execute("""
            SELECT i.*, s.name as student_name, s.enrolment_number as student_enrolment,
                   itm.name as item_name, itm.item_code, itm.tracking_type
            FROM issues i
            JOIN students s ON i.student_id = s.id
            JOIN items itm ON i.item_id = itm.id
            WHERE i.student_id = ?
            ORDER BY i.issue_date DESC
        """, (student_id,))
        student_issues = [format_issue(r, system_date) for r in cursor.fetchall()]

        data = format_student(stu)
        data['issues'] = student_issues
        return jsonify(data)

@app.route('/api/students', methods=['POST'])
def save_student():
    data = request.json or {}
    stu_id = data.get('id')
    name = data.get('name', '').strip()
    enrolment = data.get('enrolmentNumber', '').strip().upper()
    programme = data.get('programme', 'M.Sc. DFIS')
    semester = data.get('semester', 'Semester I')
    email = data.get('email', '').strip()
    phone = data.get('phone', '').strip()
    max_borrow = int(data.get('maxBorrowLimit', 3))

    if not name or not enrolment:
        return jsonify({'success': False, 'message': 'Student full name and enrolment number are required.'}), 400

    with get_db() as conn:
        cursor = conn.cursor()
        if stu_id:
            cursor.execute("""
                UPDATE students
                SET name = ?, programme = ?, semester = ?, email = ?, phone = ?, max_borrow_limit = ?
                WHERE id = ?
            """, (name, programme, semester, email, phone, max_borrow, stu_id))
            conn.commit()
            return jsonify({'success': True, 'message': f'Student profile updated.'})
        else:
            # Check unique enrolment
            cursor.execute("SELECT id FROM students WHERE enrolment_number = ?", (enrolment,))
            if cursor.fetchone():
                return jsonify({'success': False, 'message': f'Enrolment number {enrolment} is already registered.'}), 400

            new_id = f"stu-{int(datetime.now().timestamp() * 1000)}"
            cursor.execute("""
                INSERT INTO students (id, name, enrolment_number, programme, semester, email, phone, active_borrow_count, max_borrow_limit)
                VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)
            """, (new_id, name, enrolment, programme, semester, email, phone, max_borrow))

            # Auto-create user login account for student
            hashed_pwd = generate_password_hash('password123')
            user_id = f"user-{new_id}"
            cursor.execute("""
                INSERT OR IGNORE INTO users (id, username, password_hash, role, name, email, student_id, created_at)
                VALUES (?, ?, ?, 'STUDENT', ?, ?, ?, ?)
            """, (user_id, enrolment, hashed_pwd, name, email, new_id, datetime.now().strftime('%Y-%m-%d')))

            conn.commit()
            return jsonify({'success': True, 'message': f'Student {name} ({enrolment}) registered successfully.'})


# --- 6. LOCATIONS ---

@app.route('/api/locations', methods=['GET'])
def list_locations():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM locations ORDER BY laboratory ASC, room ASC")
        locs = [dict(r) for r in cursor.fetchall()]
        return jsonify(locs)


# --- 7. CORE BUSINESS RULES: ISSUE ITEMS (RULES 1, 2, 3, 4, 5) ---

@app.route('/api/issues', methods=['GET'])
def list_issues():
    with get_db() as conn:
        system_date = get_current_system_date(conn)
        student_id_filter = request.args.get('student_id')
        status_filter = request.args.get('status')
        overdue_only = request.args.get('overdue') == 'true'

        query = """
            SELECT i.*, s.name as student_name, s.enrolment_number as student_enrolment,
                   itm.name as item_name, itm.item_code, itm.tracking_type
            FROM issues i
            JOIN students s ON i.student_id = s.id
            JOIN items itm ON i.item_id = itm.id
            WHERE 1=1
        """
        params = []
        if student_id_filter:
            query += " AND i.student_id = ?"
            params.append(student_id_filter)
        if status_filter:
            query += " AND i.status = ?"
            params.append(status_filter)
        if overdue_only:
            query += " AND i.outstanding_quantity > 0 AND i.due_date < ?"
            params.append(system_date)

        query += " ORDER BY i.issue_date DESC"

        cursor = conn.cursor()
        cursor.execute(query, params)
        issues = [format_issue(row, system_date) for row in cursor.fetchall()]
        return jsonify(issues)

@app.route('/api/issue', methods=['POST'])
def issue_item():
    """
    Enforces Mandatory Rules:
    Rule 1: Registered students only
    Rule 2: Only available items in usable condition
    Rule 3: Issued quantity cannot exceed available stock
    Rule 4: Individually tracked asset cannot be issued to more than one student simultaneously
    Rule 5: Automatically calculate due date as 15 calendar days after issue date
    Rule 12: Complete transaction audit trail
    """
    data = request.json or {}
    student_id = data.get('studentId') or data.get('student_id')
    item_id = data.get('itemId') or data.get('item_id')
    asset_id = data.get('assetId') or data.get('asset_id')
    quantity = int(data.get('quantity', 1))
    purpose = data.get('purpose', '').strip()
    issue_date = data.get('issueDate') or data.get('issue_date')
    issuing_staff = data.get('issuingStaff') or data.get('issuing_staff') or 'Dr. S. K. Mehta (Coordinator)'
    notes = data.get('notes', '')

    if not student_id or not item_id:
        return jsonify({'success': False, 'message': 'Student ID and Item ID are required.'}), 400

    if quantity <= 0:
        return jsonify({'success': False, 'message': 'Requested quantity must be at least 1.'}), 400

    with get_db() as conn:
        system_date = get_current_system_date(conn)
        if not issue_date:
            issue_date = system_date

        cursor = conn.cursor()
        # Rule 1: Registered student check
        cursor.execute("SELECT * FROM students WHERE id = ?", (student_id,))
        student = cursor.fetchone()
        if not student:
            return jsonify({'success': False, 'message': 'Mandatory Rule 1 Failed: Student is not registered in the department system.'}), 400

        # Borrow limit check
        if student['active_borrow_count'] >= student['max_borrow_limit']:
            return jsonify({
                'success': False,
                'message': f"Student borrow limit exceeded: {student['name']} has reached maximum {student['max_borrow_limit']} active loans."
            }), 400

        # Rule 2 & 3: Item exists and stock available
        cursor.execute("SELECT * FROM items WHERE id = ?", (item_id,))
        item = cursor.fetchone()
        if not item:
            return jsonify({'success': False, 'message': 'Item not found in inventory catalog.'}), 404

        if item['available_quantity'] < quantity:
            return jsonify({
                'success': False,
                'message': f"Stock Unavailable: {quantity} items requested, but only {item['available_quantity']} are currently available."
            }), 400

        # Rule 4: Individually tracked asset restriction
        if item['tracking_type'] == 'INDIVIDUAL_ASSET':
            if not asset_id:
                return jsonify({'success': False, 'message': 'Please select a specific Asset ID for individually tracked equipment.'}), 400
            
            cursor.execute("SELECT * FROM individual_assets WHERE item_id = ? AND asset_id = ?", (item_id, asset_id))
            asset = cursor.fetchone()
            if not asset:
                return jsonify({'success': False, 'message': f'Asset ID {asset_id} does not exist for this item.'}), 400

            if asset['status'] != 'AVAILABLE' or asset['condition'] != 'USABLE':
                return jsonify({
                    'success': False,
                    'message': f"Mandatory Rule 4 Failed: Asset {asset_id} is currently {asset['status']} (condition: {asset['condition']}) and cannot be issued."
                }), 400

        # Rule 5: Automatic 15 calendar days due date calculation
        due_date = calculate_due_date(issue_date, 15)
        issue_id = f"issue-{int(datetime.now().timestamp() * 1000)}"
        issue_no = f"ISS-{datetime.now().strftime('%Y')}-{secrets.randbelow(9000) + 1000}"

        # Insert issue record
        cursor.execute("""
            INSERT INTO issues (id, issue_number, student_id, item_id, asset_id, quantity, outstanding_quantity, returned_quantity, purpose, issue_date, due_date, issuing_staff, status, renewal_count, acknowledgement_generated, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, 'ACTIVE', 0, 1, ?)
        """, (issue_id, issue_no, student_id, item_id, asset_id, quantity, quantity, purpose, issue_date, due_date, issuing_staff, notes))

        # Update item stock balances
        cursor.execute("""
            UPDATE items 
            SET available_quantity = available_quantity - ?, issued_quantity = issued_quantity + ?, updated_at = ?
            WHERE id = ?
        """, (quantity, quantity, issue_date, item_id))

        # Update individual asset if applicable
        if item['tracking_type'] == 'INDIVIDUAL_ASSET' and asset_id:
            cursor.execute("""
                UPDATE individual_assets
                SET status = 'ISSUED', current_student_id = ?, current_issue_id = ?
                WHERE item_id = ? AND asset_id = ?
            """, (student_id, issue_id, item_id, asset_id))

        # Increment student borrow count
        cursor.execute("UPDATE students SET active_borrow_count = active_borrow_count + 1 WHERE id = ?", (student_id,))

        # Rule 12: Audit log
        cursor.execute("""
            INSERT INTO stock_adjustments (id, item_id, asset_id, adjustment_type, quantity, reason, responsible_user, timestamp)
            VALUES (?, ?, ?, 'CORRECTION_SUBTRACT', ?, ?, ?, ?)
        """, (f"adj-{int(datetime.now().timestamp() * 1000)}", item_id, asset_id, quantity,
              f"Issued to {student['name']} ({student['enrolment_number']}) for {purpose}. Due: {due_date}",
              issuing_staff, f"{issue_date} {datetime.now().strftime('%H:%M')}"))

        conn.commit()

        # Query newly created issue with joins
        cursor.execute("""
            SELECT i.*, s.name as student_name, s.enrolment_number as student_enrolment,
                   itm.name as item_name, itm.item_code, itm.tracking_type
            FROM issues i
            JOIN students s ON i.student_id = s.id
            JOIN items itm ON i.item_id = itm.id
            WHERE i.id = ?
        """, (issue_id,))
        new_issue = format_issue(cursor.fetchone(), system_date)

        return jsonify({
            'success': True,
            'message': f"Item successfully issued to {student['name']}. Due date set to {due_date} (15 calendar days).",
            'issueRecord': new_issue,
            'issue_number': issue_no,
            'due_date': due_date
        })


# --- 8. CORE BUSINESS RULES: RECORD RETURNS (RULES 9, 10, 11) ---

@app.route('/api/returns', methods=['GET'])
def list_returns():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT r.*, s.name as student_name, itm.name as item_name
            FROM returns r
            JOIN students s ON r.student_id = s.id
            JOIN items itm ON r.item_id = itm.id
            ORDER BY r.return_date DESC
        """)
        returns = [format_return(row) for row in cursor.fetchall()]
        return jsonify(returns)

@app.route('/api/return', methods=['POST'])
def record_return():
    """
    Enforces Mandatory Rules:
    Rule 9: Returned items become available only after receipt and condition are recorded
    Rule 10: Damaged or maintenance items remain unavailable until coordinator updates status
    Rule 11: Partial returns supported with accurate outstanding quantities
    Rule 12: Audit logged with date and responsible staff
    """
    data = request.json or {}
    issue_id = data.get('issueId') or data.get('issue_id')
    qty_returned = int(data.get('quantityReturned') or data.get('quantity_returned', 1))
    return_date = data.get('returnDate') or data.get('return_date')
    condition = data.get('conditionOnReturn') or data.get('condition_on_return') or 'USABLE'
    receiving_staff = data.get('receivingStaff') or data.get('receiving_staff') or 'Dr. S. K. Mehta (Coordinator)'
    remarks = data.get('remarks', '').strip()

    if not issue_id:
        return jsonify({'success': False, 'message': 'Issue ID is required.'}), 400

    if qty_returned <= 0:
        return jsonify({'success': False, 'message': 'Return quantity must be greater than 0.'}), 400

    with get_db() as conn:
        system_date = get_current_system_date(conn)
        if not return_date:
            return_date = system_date

        cursor = conn.cursor()
        cursor.execute("SELECT * FROM issues WHERE id = ?", (issue_id,))
        issue = cursor.fetchone()
        if not issue:
            return jsonify({'success': False, 'message': 'Issue record not found.'}), 404

        if qty_returned > issue['outstanding_quantity']:
            return jsonify({
                'success': False,
                'message': f"Invalid return quantity: Student has {issue['outstanding_quantity']} outstanding, but {qty_returned} was entered."
            }), 400

        cursor.execute("SELECT * FROM items WHERE id = ?", (issue['item_id'],))
        item = cursor.fetchone()
        if not item:
            return jsonify({'success': False, 'message': 'Item record not found.'}), 404

        cursor.execute("SELECT * FROM students WHERE id = ?", (issue['student_id'],))
        student = cursor.fetchone()

        is_partial = qty_returned < issue['outstanding_quantity']
        new_outstanding = issue['outstanding_quantity'] - qty_returned
        new_status = 'RETURNED' if new_outstanding == 0 else 'PARTIALLY_RETURNED'

        # Update Issue Record
        cursor.execute("""
            UPDATE issues
            SET outstanding_quantity = ?, returned_quantity = returned_quantity + ?, status = ?
            WHERE id = ?
        """, (new_outstanding, qty_returned, new_status, issue_id))

        # Decrement student active loans count if fully returned
        if new_outstanding == 0 and student and student['active_borrow_count'] > 0:
            cursor.execute("UPDATE students SET active_borrow_count = active_borrow_count - 1 WHERE id = ?", (issue['student_id'],))

        # Update Item Stock Counts according to Condition
        # Rule 9 & 10: Only restore to available if usable condition
        cursor.execute("UPDATE items SET issued_quantity = issued_quantity - ? WHERE id = ?", (qty_returned, issue['item_id']))
        if condition == 'USABLE':
            cursor.execute("UPDATE items SET available_quantity = available_quantity + ? WHERE id = ?", (qty_returned, issue['item_id']))
        elif condition == 'DAMAGED':
            cursor.execute("UPDATE items SET damaged_quantity = damaged_quantity + ? WHERE id = ?", (qty_returned, issue['item_id']))
        elif condition == 'IN_MAINTENANCE':
            cursor.execute("UPDATE items SET maintenance_quantity = maintenance_quantity + ? WHERE id = ?", (qty_returned, issue['item_id']))
        elif condition == 'RETIRED':
            cursor.execute("UPDATE items SET retired_quantity = retired_quantity + ? WHERE id = ?", (qty_returned, issue['item_id']))

        # Update Individual Asset if applicable
        if item['tracking_type'] == 'INDIVIDUAL_ASSET' and issue['asset_id']:
            new_asset_status = 'AVAILABLE' if condition == 'USABLE' else ('IN_MAINTENANCE' if condition in ('DAMAGED', 'IN_MAINTENANCE') else 'RETIRED')
            curr_stu = None if new_outstanding == 0 else issue['student_id']
            curr_iss = None if new_outstanding == 0 else issue_id
            cursor.execute("""
                UPDATE individual_assets
                SET status = ?, condition = ?, current_student_id = ?, current_issue_id = ?
                WHERE item_id = ? AND asset_id = ?
            """, (new_asset_status, condition, curr_stu, curr_iss, issue['item_id'], issue['asset_id']))

        # Insert Return Record
        ret_id = f"ret-{int(datetime.now().timestamp() * 1000)}"
        cursor.execute("""
            INSERT INTO returns (id, issue_id, student_id, item_id, asset_id, quantity_returned, return_date, condition_on_return, receiving_staff, remarks, is_partial)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (ret_id, issue_id, issue['student_id'], issue['item_id'], issue['asset_id'], qty_returned, return_date, condition, receiving_staff, remarks, 1 if is_partial else 0))

        # Rule 12: Audit trail
        adj_type = 'CORRECTION_ADD' if condition == 'USABLE' else 'DAMAGE_FLAG'
        cursor.execute("""
            INSERT INTO stock_adjustments (id, item_id, asset_id, adjustment_type, quantity, reason, responsible_user, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (f"adj-{int(datetime.now().timestamp() * 1000)}", issue['item_id'], issue['asset_id'], adj_type, qty_returned,
              f"Return recorded from {student['name'] if student else ''} ({condition} condition). Remarks: {remarks}",
              receiving_staff, f"{return_date} {datetime.now().strftime('%H:%M')}"))

        conn.commit()

        msg = (f"Partial return of {qty_returned} unit(s) recorded. {new_outstanding} unit(s) remain outstanding."
               if is_partial else
               f"Complete return of {item['name']} successfully recorded. Condition: {condition}.")

        return jsonify({
            'success': True,
            'message': msg,
            'is_partial': is_partial
        })


# --- 9. CORE BUSINESS RULES: RENEWALS (RULES 6, 7, 8) ---

@app.route('/api/renewals', methods=['GET'])
def list_renewals():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT r.*, s.name as student_name, s.enrolment_number as student_enrolment,
                   itm.name as item_name, i.asset_id
            FROM renewals r
            JOIN issues i ON r.issue_id = i.id
            JOIN students s ON r.student_id = s.id
            JOIN items itm ON i.item_id = itm.id
            ORDER BY r.request_date DESC
        """)
        renewals = [format_renewal(row) for row in cursor.fetchall()]
        return jsonify(renewals)

@app.route('/api/renew/request', methods=['POST'])
def request_renewal():
    """
    Enforces Mandatory Rules:
    Rule 6: Students must return or obtain approved renewal by due date
    Rule 7: Submitting renewal request alone does NOT extend due date; coordinator approval is required
    """
    data = request.json or {}
    issue_id = data.get('issueId') or data.get('issue_id')
    student_id = data.get('studentId') or data.get('student_id')
    remarks = data.get('remarks', '').strip()

    # If authenticated student session, enforce that student_id matches session
    with get_db() as conn:
        session_user = get_session_user(conn)
        if session_user and session_user['role'] == 'STUDENT':
            student_id = session_user['student_id']

        if not issue_id:
            return jsonify({'success': False, 'message': 'Issue ID is required.'}), 400

        system_date = get_current_system_date(conn)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM issues WHERE id = ?", (issue_id,))
        issue = cursor.fetchone()
        if not issue:
            return jsonify({'success': False, 'message': 'Issue record not found.'}), 404

        if student_id and issue['student_id'] != student_id:
            return jsonify({'success': False, 'message': 'Unauthorized: You can only renew items issued to your student account.'}), 403

        if issue['outstanding_quantity'] <= 0:
            return jsonify({'success': False, 'message': 'This item has already been fully returned.'}), 400

        if issue['renewal_count'] >= 2:
            return jsonify({'success': False, 'message': 'Maximum renewal limit (2 times) reached for this loan. Please return the item.'}), 400

        cursor.execute("SELECT * FROM renewals WHERE issue_id = ? AND status = 'PENDING'", (issue_id,))
        if cursor.fetchone():
            return jsonify({'success': False, 'message': 'A renewal request is already pending coordinator approval for this item.'}), 400

        # Rule 8: Proposed due date = current due date + 15 calendar days
        proposed_due = calculate_due_date(issue['due_date'], 15)
        ren_id = f"ren-{int(datetime.now().timestamp() * 1000)}"

        cursor.execute("""
            INSERT INTO renewals (id, issue_id, student_id, request_date, status, original_due_date, proposed_due_date, remarks)
            VALUES (?, ?, ?, ?, 'PENDING', ?, ?, ?)
        """, (ren_id, issue_id, issue['student_id'], system_date, issue['due_date'], proposed_due, remarks))
        conn.commit()

        # Rule 7: Due date remains unchanged until approved by coordinator
        return jsonify({
            'success': True,
            'message': f"Renewal request submitted. Current due date remains {issue['due_date']} until approved by the coordinator (Rule 7)."
        })

@app.route('/api/renew/review', methods=['POST'])
def review_renewal():
    """
    Enforces Mandatory Rules:
    Rule 8: Each approved renewal extends due date by 15 calendar days from existing due date
    Rule 7: Rejected renewals leave original due date in effect
    """
    data = request.json or {}
    renewal_id = data.get('renewalId') or data.get('renewal_id')
    approve = data.get('approve', False)
    remarks = data.get('remarks', '').strip()
    staff = data.get('approvingStaff') or data.get('approving_staff') or 'Dr. S. K. Mehta (Coordinator)'

    if not renewal_id:
        return jsonify({'success': False, 'message': 'Renewal ID is required.'}), 400

    with get_db() as conn:
        system_date = get_current_system_date(conn)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM renewals WHERE id = ?", (renewal_id,))
        ren = cursor.fetchone()
        if not ren:
            return jsonify({'success': False, 'message': 'Renewal record not found.'}), 404

        if ren['status'] != 'PENDING':
            return jsonify({'success': False, 'message': f"Renewal has already been reviewed ({ren['status']})."}), 400

        cursor.execute("SELECT * FROM issues WHERE id = ?", (ren['issue_id'],))
        issue = cursor.fetchone()
        if not issue:
            return jsonify({'success': False, 'message': 'Associated issue record not found.'}), 404

        if approve:
            # Rule 8: Revised due date = Existing Due Date + 15 calendar days
            revised_due = calculate_due_date(issue['due_date'], 15)
            new_status = 'OVERDUE' if (system_date > revised_due and issue['outstanding_quantity'] > 0) else 'ACTIVE'

            cursor.execute("""
                UPDATE renewals
                SET status = 'APPROVED', revised_due_date = ?, approving_staff = ?, remarks = ?
                WHERE id = ?
            """, (revised_due, staff, remarks, renewal_id))

            cursor.execute("""
                UPDATE issues
                SET due_date = ?, renewal_count = renewal_count + 1, last_renewal_date = ?, status = ?
                WHERE id = ?
            """, (revised_due, system_date, new_status, ren['issue_id']))

            # Audit log
            cursor.execute("SELECT name FROM students WHERE id = ?", (issue['student_id'],))
            stu_name = cursor.fetchone()['name']
            cursor.execute("""
                INSERT INTO stock_adjustments (id, item_id, asset_id, adjustment_type, quantity, reason, responsible_user, timestamp)
                VALUES (?, ?, ?, 'CORRECTION_ADD', 0, ?, ?, ?)
            """, (f"adj-{int(datetime.now().timestamp() * 1000)}", issue['item_id'], issue['asset_id'],
                  f"Renewal approved for {stu_name}. Due date extended by 15 days to {revised_due}. Remarks: {remarks}",
                  staff, f"{system_date} {datetime.now().strftime('%H:%M')}"))

            conn.commit()
            return jsonify({
                'success': True,
                'message': f"Renewal approved! Due date extended by 15 calendar days to {revised_due}."
            })
        else:
            cursor.execute("""
                UPDATE renewals
                SET status = 'REJECTED', approving_staff = ?, remarks = ?
                WHERE id = ?
            """, (staff, remarks, renewal_id))
            conn.commit()
            return jsonify({
                'success': True,
                'message': f"Renewal rejected. Original due date ({issue['due_date']}) remains in effect."
            })


# --- 10. STOCK ADJUSTMENTS & RETIREMENT (RULE 10 & 12) ---

@app.route('/api/stock-adjustments', methods=['GET'])
def list_adjustments():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT a.*, itm.name as item_name
            FROM stock_adjustments a
            JOIN items itm ON a.item_id = itm.id
            ORDER BY a.timestamp DESC
        """)
        adjustments = [format_adjustment(row) for row in cursor.fetchall()]
        return jsonify(adjustments)

@app.route('/api/stock-adjustments', methods=['POST'])
def adjust_stock():
    data = request.json or {}
    item_id = data.get('itemId') or data.get('item_id')
    asset_id = data.get('assetId') or data.get('asset_id')
    adj_type = data.get('adjustmentType') or data.get('adjustment_type')
    quantity = int(data.get('quantity', 1))
    reason = data.get('reason', '').strip()
    responsible_user = data.get('responsibleUser') or data.get('responsible_user') or 'Dr. S. K. Mehta (Coordinator)'

    if not item_id or not adj_type:
        return jsonify({'success': False, 'message': 'Item ID and adjustment type are required.'}), 400

    if not reason:
        return jsonify({'success': False, 'message': 'Rule 12: A documented reason is required for all stock adjustments.'}), 400

    with get_db() as conn:
        system_date = get_current_system_date(conn)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM items WHERE id = ?", (item_id,))
        item = cursor.fetchone()
        if not item:
            return jsonify({'success': False, 'message': 'Item not found.'}), 404

        if adj_type == 'NEW_STOCK':
            cursor.execute("""
                UPDATE items
                SET total_quantity = total_quantity + ?, available_quantity = available_quantity + ?, updated_at = ?
                WHERE id = ?
            """, (quantity, quantity, system_date, item_id))
            if item['tracking_type'] == 'INDIVIDUAL_ASSET' and asset_id:
                cursor.execute("""
                    INSERT INTO individual_assets (id, item_id, asset_id, location, condition, status)
                    VALUES (?, ?, ?, ?, 'USABLE', 'AVAILABLE')
                """, (f"asset-{int(datetime.now().timestamp() * 1000)}", item_id, asset_id, item['location']))

        elif adj_type == 'CORRECTION_ADD':
            cursor.execute("""
                UPDATE items
                SET total_quantity = total_quantity + ?, available_quantity = available_quantity + ?, updated_at = ?
                WHERE id = ?
            """, (quantity, quantity, system_date, item_id))

        elif adj_type == 'CORRECTION_SUBTRACT':
            if item['available_quantity'] < quantity:
                return jsonify({'success': False, 'message': f"Cannot reduce: Only {item['available_quantity']} available in usable stock."}), 400
            cursor.execute("""
                UPDATE items
                SET total_quantity = total_quantity - ?, available_quantity = available_quantity - ?, updated_at = ?
                WHERE id = ?
            """, (quantity, quantity, system_date, item_id))

        elif adj_type == 'DAMAGE_FLAG':
            if item['available_quantity'] < quantity:
                return jsonify({'success': False, 'message': f"Only {item['available_quantity']} available to flag as damaged."}), 400
            cursor.execute("""
                UPDATE items
                SET available_quantity = available_quantity - ?, damaged_quantity = damaged_quantity + ?, updated_at = ?
                WHERE id = ?
            """, (quantity, quantity, system_date, item_id))
            if item['tracking_type'] == 'INDIVIDUAL_ASSET' and asset_id:
                cursor.execute("""
                    UPDATE individual_assets SET condition = 'DAMAGED', status = 'IN_MAINTENANCE'
                    WHERE item_id = ? AND asset_id = ?
                """, (item_id, asset_id))

        elif adj_type == 'RESTORE_TO_USABLE':
            current_damaged = item['damaged_quantity'] + item['maintenance_quantity']
            if current_damaged < quantity:
                return jsonify({'success': False, 'message': 'Quantity exceeds currently damaged or maintenance stock.'}), 400
            if item['damaged_quantity'] >= quantity:
                cursor.execute("UPDATE items SET damaged_quantity = damaged_quantity - ? WHERE id = ?", (quantity, item_id))
            else:
                rem = quantity - item['damaged_quantity']
                cursor.execute("UPDATE items SET damaged_quantity = 0, maintenance_quantity = maintenance_quantity - ? WHERE id = ?", (rem, item_id))
            cursor.execute("UPDATE items SET available_quantity = available_quantity + ?, updated_at = ? WHERE id = ?", (quantity, system_date, item_id))
            if item['tracking_type'] == 'INDIVIDUAL_ASSET' and asset_id:
                cursor.execute("""
                    UPDATE individual_assets SET condition = 'USABLE', status = 'AVAILABLE'
                    WHERE item_id = ? AND asset_id = ?
                """, (item_id, asset_id))

        elif adj_type == 'RETIREMENT':
            if item['available_quantity'] < quantity:
                return jsonify({'success': False, 'message': f"Cannot retire: Available quantity is less than {quantity}."}), 400
            cursor.execute("""
                UPDATE items
                SET total_quantity = total_quantity - ?, available_quantity = available_quantity - ?, retired_quantity = retired_quantity + ?, updated_at = ?
                WHERE id = ?
            """, (quantity, quantity, quantity, system_date, item_id))
            if item['tracking_type'] == 'INDIVIDUAL_ASSET' and asset_id:
                cursor.execute("""
                    UPDATE individual_assets SET condition = 'RETIRED', status = 'RETIRED'
                    WHERE item_id = ? AND asset_id = ?
                """, (item_id, asset_id))

        # Insert audit record
        cursor.execute("""
            INSERT INTO stock_adjustments (id, item_id, asset_id, adjustment_type, quantity, reason, responsible_user, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (f"adj-{int(datetime.now().timestamp() * 1000)}", item_id, asset_id, adj_type, quantity, reason, responsible_user,
              f"{system_date} {datetime.now().strftime('%H:%M')}"))

        conn.commit()
        return jsonify({'success': True, 'message': f"Stock adjustment ({adj_type}) successfully recorded."})


# --- 11. STUDENT-SPECIFIC AUTHORIZED ENDPOINTS ---

@app.route('/api/student/me/issues', methods=['GET'])
def get_my_issues():
    with get_db() as conn:
        system_date = get_current_system_date(conn)
        user = get_session_user(conn)
        # Fallback to query param for development / UI student switcher
        student_id = user['student_id'] if (user and user['student_id']) else request.args.get('student_id')
        if not student_id:
            return jsonify({'success': False, 'message': 'Student ID required.'}), 400

        cursor = conn.cursor()
        cursor.execute("""
            SELECT i.*, s.name as student_name, s.enrolment_number as student_enrolment,
                   itm.name as item_name, itm.item_code, itm.tracking_type
            FROM issues i
            JOIN students s ON i.student_id = s.id
            JOIN items itm ON i.item_id = itm.id
            WHERE i.student_id = ?
            ORDER BY i.issue_date DESC
        """, (student_id,))
        issues = [format_issue(row, system_date) for row in cursor.fetchall()]
        return jsonify(issues)

@app.route('/api/student/me/renewals', methods=['GET'])
def get_my_renewals():
    with get_db() as conn:
        user = get_session_user(conn)
        student_id = user['student_id'] if (user and user['student_id']) else request.args.get('student_id')
        if not student_id:
            return jsonify({'success': False, 'message': 'Student ID required.'}), 400

        cursor = conn.cursor()
        cursor.execute("""
            SELECT r.*, s.name as student_name, s.enrolment_number as student_enrolment,
                   itm.name as item_name, i.asset_id
            FROM renewals r
            JOIN issues i ON r.issue_id = i.id
            JOIN students s ON r.student_id = s.id
            JOIN items itm ON i.item_id = itm.id
            WHERE r.student_id = ?
            ORDER BY r.request_date DESC
        """, (student_id,))
        renewals = [format_renewal(row) for row in cursor.fetchall()]
        return jsonify(renewals)

@app.route('/api/student/me/returns', methods=['GET'])
def get_my_returns():
    with get_db() as conn:
        user = get_session_user(conn)
        student_id = user['student_id'] if (user and user['student_id']) else request.args.get('student_id')
        if not student_id:
            return jsonify({'success': False, 'message': 'Student ID required.'}), 400

        cursor = conn.cursor()
        cursor.execute("""
            SELECT r.*, s.name as student_name, itm.name as item_name
            FROM returns r
            JOIN students s ON r.student_id = s.id
            JOIN items itm ON r.item_id = itm.id
            WHERE r.student_id = ?
            ORDER BY r.return_date DESC
        """, (student_id,))
        returns = [format_return(row) for row in cursor.fetchall()]
        return jsonify(returns)


# --- 12. RUN INITIALIZATION ---
init_db()

if __name__ == '__main__':
    print("M.Sc. DFIS Inventory System backend starting on http://0.0.0.0:5000...")
    app.run(host='0.0.0.0', port=5000, debug=True)
