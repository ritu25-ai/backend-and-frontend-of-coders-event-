-- Department of Digital Forensics & Information Security
-- Database Schema for Inventory and Student Item Issue Management System
-- SQLite 3 Compatible

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS locations (
    id TEXT PRIMARY KEY,
    department TEXT NOT NULL,
    laboratory TEXT NOT NULL,
    room TEXT NOT NULL,
    cupboard TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS items (
    id TEXT PRIMARY KEY,
    item_code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT,
    make_model TEXT,
    tracking_type TEXT CHECK(tracking_type IN ('INDIVIDUAL_ASSET', 'QUANTITY_REUSABLE')) NOT NULL,
    total_quantity INTEGER NOT NULL DEFAULT 1,
    available_quantity INTEGER NOT NULL DEFAULT 1,
    issued_quantity INTEGER NOT NULL DEFAULT 0,
    damaged_quantity INTEGER NOT NULL DEFAULT 0,
    maintenance_quantity INTEGER NOT NULL DEFAULT 0,
    retired_quantity INTEGER NOT NULL DEFAULT 0,
    location TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS individual_assets (
    id TEXT PRIMARY KEY,
    item_id TEXT NOT NULL,
    asset_id TEXT UNIQUE NOT NULL, -- e.g. 'DB-001'
    serial_number TEXT,
    location TEXT NOT NULL,
    condition TEXT CHECK(condition IN ('USABLE', 'DAMAGED', 'IN_MAINTENANCE', 'RETIRED')) NOT NULL DEFAULT 'USABLE',
    status TEXT CHECK(status IN ('AVAILABLE', 'ISSUED', 'IN_MAINTENANCE', 'RETIRED')) NOT NULL DEFAULT 'AVAILABLE',
    current_student_id TEXT,
    current_issue_id TEXT,
    FOREIGN KEY(item_id) REFERENCES items(id) ON DELETE CASCADE,
    FOREIGN KEY(current_student_id) REFERENCES students(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS students (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    enrolment_number TEXT UNIQUE NOT NULL, -- e.g. 'DFIS26001'
    programme TEXT NOT NULL DEFAULT 'M.Sc. DFIS',
    semester TEXT NOT NULL DEFAULT 'Semester I',
    email TEXT,
    phone TEXT,
    active_borrow_count INTEGER NOT NULL DEFAULT 0,
    max_borrow_limit INTEGER NOT NULL DEFAULT 3
);

CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT CHECK(role IN ('COORDINATOR', 'STUDENT')) NOT NULL,
    name TEXT NOT NULL,
    email TEXT,
    student_id TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    role TEXT NOT NULL,
    student_id TEXT,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS issues (
    id TEXT PRIMARY KEY,
    issue_number TEXT UNIQUE NOT NULL,
    student_id TEXT NOT NULL,
    item_id TEXT NOT NULL,
    asset_id TEXT,
    quantity INTEGER NOT NULL,
    outstanding_quantity INTEGER NOT NULL,
    returned_quantity INTEGER NOT NULL DEFAULT 0,
    purpose TEXT NOT NULL,
    issue_date TEXT NOT NULL, -- YYYY-MM-DD
    due_date TEXT NOT NULL,   -- Exactly 15 calendar days from issue_date
    issuing_staff TEXT NOT NULL,
    status TEXT CHECK(status IN ('ACTIVE', 'PARTIALLY_RETURNED', 'RETURNED', 'OVERDUE')) NOT NULL DEFAULT 'ACTIVE',
    renewal_count INTEGER NOT NULL DEFAULT 0,
    last_renewal_date TEXT,
    acknowledgement_generated BOOLEAN NOT NULL DEFAULT 1,
    notes TEXT,
    FOREIGN KEY(student_id) REFERENCES students(id),
    FOREIGN KEY(item_id) REFERENCES items(id)
);

CREATE TABLE IF NOT EXISTS returns (
    id TEXT PRIMARY KEY,
    issue_id TEXT NOT NULL,
    student_id TEXT NOT NULL,
    item_id TEXT NOT NULL,
    asset_id TEXT,
    quantity_returned INTEGER NOT NULL,
    return_date TEXT NOT NULL,
    condition_on_return TEXT CHECK(condition_on_return IN ('USABLE', 'DAMAGED', 'IN_MAINTENANCE', 'RETIRED')) NOT NULL,
    receiving_staff TEXT NOT NULL,
    remarks TEXT,
    is_partial BOOLEAN NOT NULL DEFAULT 0,
    FOREIGN KEY(issue_id) REFERENCES issues(id),
    FOREIGN KEY(student_id) REFERENCES students(id),
    FOREIGN KEY(item_id) REFERENCES items(id)
);

CREATE TABLE IF NOT EXISTS renewals (
    id TEXT PRIMARY KEY,
    issue_id TEXT NOT NULL,
    student_id TEXT NOT NULL,
    request_date TEXT NOT NULL,
    status TEXT CHECK(status IN ('PENDING', 'APPROVED', 'REJECTED')) NOT NULL DEFAULT 'PENDING',
    original_due_date TEXT NOT NULL,
    proposed_due_date TEXT NOT NULL, -- original_due_date + 15 calendar days
    revised_due_date TEXT,
    approving_staff TEXT,
    remarks TEXT,
    FOREIGN KEY(issue_id) REFERENCES issues(id),
    FOREIGN KEY(student_id) REFERENCES students(id)
);

CREATE TABLE IF NOT EXISTS stock_adjustments (
    id TEXT PRIMARY KEY,
    item_id TEXT NOT NULL,
    asset_id TEXT,
    adjustment_type TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    reason TEXT NOT NULL,
    responsible_user TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    FOREIGN KEY(item_id) REFERENCES items(id)
);

CREATE TABLE IF NOT EXISTS system_settings (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT NOT NULL
);
