"""
Automated Backend Test Suite
Covers Problem Statement #5: Department Inventory & Student Item Issue Management System
All 12 Mandatory Business Rules + Security + Concurrency & Consistency
"""

import unittest
import json
import os
import sys

# Ensure backend_flask is in python path
sys.path.insert(0, os.path.dirname(__file__))

from app import app, init_db, get_db

class InventoryBackendTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()

    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True
        # Reset database to fresh seed state before each test
        res = self.app.post('/api/system/reset')
        self.assertEqual(res.status_code, 200)

    # --- 1. Authentication Tests ---
    def test_coordinator_login_success(self):
        res = self.app.post('/api/auth/login', json={
            'username': 'coordinator@dfis.univ.edu',
            'password': 'password123'
        })
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertTrue(data['success'])
        self.assertIn('token', data)
        self.assertEqual(data['user']['role'], 'COORDINATOR')

    def test_student_login_success(self):
        res = self.app.post('/api/auth/login', json={
            'username': 'DFIS26001',
            'password': 'password123'
        })
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertTrue(data['success'])
        self.assertEqual(data['user']['role'], 'STUDENT')
        self.assertEqual(data['user']['studentId'], 'stu-01')

    def test_login_invalid_password(self):
        res = self.app.post('/api/auth/login', json={
            'username': 'DFIS26001',
            'password': 'wrongpassword'
        })
        self.assertEqual(res.status_code, 401)

    # --- 2. Seed Data Validation (Problem Statement Section 5) ---
    def test_seed_inventory_counts(self):
        # 10 development boards (9 available, 1 issued)
        # 20 reusable USB cables (18 available, 2 issued)
        res = self.app.get('/api/items')
        self.assertEqual(res.status_code, 200)
        items = json.loads(res.data)
        
        dev_board = next((i for i in items if i['id'] == 'item-dev-board-01'), None)
        self.assertIsNotNone(dev_board)
        self.assertEqual(dev_board['totalQuantity'], 10)
        self.assertEqual(dev_board['availableQuantity'], 9)
        self.assertEqual(dev_board['issuedQuantity'], 1)
        self.assertEqual(len(dev_board['individualAssets']), 10)

        usb_cable = next((i for i in items if i['id'] == 'item-usb-cable-01'), None)
        self.assertIsNotNone(usb_cable)
        self.assertEqual(usb_cable['totalQuantity'], 20)
        self.assertEqual(usb_cable['availableQuantity'], 18)
        self.assertEqual(usb_cable['issuedQuantity'], 2)

    # --- 3. Mandatory Rule 1: Registered students only ---
    def test_rule_1_unregistered_student_cannot_borrow(self):
        res = self.app.post('/api/issue', json={
            'studentId': 'unregistered-student-999',
            'itemId': 'item-dev-board-01',
            'assetId': 'DB-002',
            'quantity': 1,
            'purpose': 'Testing non-existent student',
            'issueDate': '2026-10-01'
        })
        self.assertEqual(res.status_code, 400)
        data = json.loads(res.data)
        self.assertFalse(data['success'])
        self.assertIn('Rule 1', data['message'])

    # --- 4. Mandatory Rule 2 & 3: Stock availability limit ---
    def test_rule_2_3_insufficient_stock_fails_with_explanation(self):
        # Only 18 USB cables available
        res = self.app.post('/api/issue', json={
            'studentId': 'stu-04',
            'itemId': 'item-usb-cable-01',
            'quantity': 25,
            'purpose': 'Requesting more cables than in department stock',
            'issueDate': '2026-10-01'
        })
        self.assertEqual(res.status_code, 400)
        data = json.loads(res.data)
        self.assertFalse(data['success'])
        self.assertIn('Stock Unavailable', data['message'])
        self.assertIn('only 18 are currently available', data['message'])

    # --- 5. Mandatory Rule 4: Individually tracked asset double-booking prevention ---
    def test_rule_4_cannot_issue_already_issued_asset(self):
        # DB-001 is already issued to Rahul Sharma
        res = self.app.post('/api/issue', json={
            'studentId': 'stu-04',
            'itemId': 'item-dev-board-01',
            'assetId': 'DB-001',
            'quantity': 1,
            'purpose': 'Attempting double-issue of DB-001',
            'issueDate': '2026-10-02'
        })
        self.assertEqual(res.status_code, 400)
        data = json.loads(res.data)
        self.assertFalse(data['success'])
        self.assertIn('Rule 4', data['message'])

    # --- 6. Mandatory Rule 5: Automatic 15-day due date calculation ---
    def test_rule_5_issue_on_1_oct_due_on_16_oct(self):
        res = self.app.post('/api/issue', json={
            'studentId': 'stu-04',
            'itemId': 'item-dev-board-01',
            'assetId': 'DB-002',
            'quantity': 1,
            'purpose': 'Firmware Lab',
            'issueDate': '2026-10-01',
            'issuingStaff': 'Dr. S. K. Mehta (Coordinator)'
        })
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertTrue(data['success'])
        self.assertEqual(data['due_date'], '2026-10-16')

        # Stock reduced: 9 -> 8
        item_res = self.app.get('/api/items/item-dev-board-01')
        item = json.loads(item_res.data)
        self.assertEqual(item['availableQuantity'], 8)
        self.assertEqual(item['issuedQuantity'], 2)

    # --- 7. Mandatory Rule 6 & 7: Renewal request does not change due date alone ---
    def test_rule_6_7_renewal_request_leaves_due_date_unchanged(self):
        # issue-01 is due 2026-10-16
        res = self.app.post('/api/renew/request', json={
            'issueId': 'issue-01',
            'studentId': 'stu-01',
            'remarks': 'Need more time for assignment'
        })
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertTrue(data['success'])
        self.assertIn('Rule 7', data['message'])

        # Verify due date of issue-01 is still 2026-10-16
        issues_res = self.app.get('/api/issues?student_id=stu-01')
        issues = json.loads(issues_res.data)
        issue_1 = next(i for i in issues if i['id'] == 'issue-01')
        self.assertEqual(issue_1['dueDate'], '2026-10-16')

    # --- 8. Mandatory Rule 8: Approval extends due date by +15 days (16 Oct -> 31 Oct) ---
    def test_rule_8_renewal_approval_extends_to_31_oct(self):
        # First request renewal for issue-01
        self.app.post('/api/renew/request', json={
            'issueId': 'issue-01',
            'studentId': 'stu-01',
            'remarks': 'Need extension'
        })

        # Get the pending renewal
        ren_res = self.app.get('/api/renewals')
        renewals = json.loads(ren_res.data)
        ren_01 = next(r for r in renewals if r['issueId'] == 'issue-01' and r['status'] == 'PENDING')
        self.assertEqual(ren_01['originalDueDate'], '2026-10-16')
        self.assertEqual(ren_01['proposedDueDate'], '2026-10-31')

        # Coordinator approves
        approve_res = self.app.post('/api/renew/review', json={
            'renewalId': ren_01['id'],
            'approve': True,
            'remarks': 'Approved by coordinator',
            'approvingStaff': 'Dr. S. K. Mehta'
        })
        self.assertEqual(approve_res.status_code, 200)
        app_data = json.loads(approve_res.data)
        self.assertTrue(app_data['success'])
        self.assertIn('2026-10-31', app_data['message'])

        # Check that issue-01 due date is now 2026-10-31
        issues_res = self.app.get('/api/issues')
        issues = json.loads(issues_res.data)
        issue_1 = next(i for i in issues if i['id'] == 'issue-01')
        self.assertEqual(issue_1['dueDate'], '2026-10-31')
        self.assertEqual(issue_1['renewalCount'], 1)

    # --- 9. Mandatory Rule 9 & 10: Condition inspection on return ---
    def test_rule_9_10_damaged_return_remains_unavailable(self):
        # Return 1 cable from issue-02 as DAMAGED
        res = self.app.post('/api/return', json={
            'issueId': 'issue-02',
            'quantityReturned': 1,
            'returnDate': '2026-10-10',
            'conditionOnReturn': 'DAMAGED',
            'receivingStaff': 'Dr. S. K. Mehta',
            'remarks': 'Cable connector damaged'
        })
        self.assertEqual(res.status_code, 200)
        
        # Available stock must NOT increase; damaged_quantity must increase by 1
        item_res = self.app.get('/api/items/item-usb-cable-01')
        item = json.loads(item_res.data)
        self.assertEqual(item['availableQuantity'], 18)
        self.assertEqual(item['damagedQuantity'], 1)
        self.assertEqual(item['issuedQuantity'], 1)

    # --- 10. Mandatory Rule 11: Partial returns ---
    def test_rule_11_partial_returns_accurate_outstanding(self):
        # Set system date to 2026-10-05 (before due date of 16 Oct)
        self.app.post('/api/system/date', json={'systemDate': '2026-10-05'})
        
        # issue-02 has 2 cables outstanding. Return 1.
        res = self.app.post('/api/return', json={
            'issueId': 'issue-02',
            'quantityReturned': 1,
            'returnDate': '2026-10-05',
            'conditionOnReturn': 'USABLE',
            'receivingStaff': 'Dr. S. K. Mehta',
            'remarks': 'Returned 1 usable cable'
        })
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertTrue(data['is_partial'])

        issues_res = self.app.get('/api/issues')
        issues = json.loads(issues_res.data)
        issue_2 = next(i for i in issues if i['id'] == 'issue-02')
        self.assertEqual(issue_2['outstandingQuantity'], 1)
        self.assertEqual(issue_2['returnedQuantity'], 1)
        self.assertEqual(issue_2['status'], 'PARTIALLY_RETURNED')

    # --- 11. Overdue Detection: Due 16 Oct vs System Date 19 Oct -> 3 days overdue ---
    def test_overdue_calculation(self):
        res = self.app.get('/api/dashboard')
        data = json.loads(res.data)
        # Default system date is 2026-10-19; issues due 2026-10-16 or earlier are overdue
        self.assertGreater(data['overdue_count'], 0)

        issues_res = self.app.get('/api/issues?overdue=true')
        overdue_issues = json.loads(issues_res.data)
        self.assertTrue(any(i['id'] == 'issue-01' for i in overdue_issues))

    # --- 12. Security & Privacy: Student isolation ---
    def test_student_cannot_renew_another_student_issue(self):
        # issue-03 belongs to stu-02 (Ananya Iyer). stu-01 cannot renew it.
        login_res = self.app.post('/api/auth/login', json={
            'username': 'DFIS26001', # stu-01
            'password': 'password123'
        })
        token = json.loads(login_res.data)['token']

        res = self.app.post('/api/renew/request', json={
            'issueId': 'issue-03',
            'studentId': 'stu-01',
            'remarks': 'Illegitimate attempt'
        }, headers={'Authorization': f'Bearer {token}'})
        self.assertEqual(res.status_code, 403)

if __name__ == '__main__':
    unittest.main()
