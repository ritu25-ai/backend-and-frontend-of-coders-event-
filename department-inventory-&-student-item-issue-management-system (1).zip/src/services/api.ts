import { 
  InventoryItem, 
  Student, 
  IssueRecord, 
  ReturnRecord, 
  RenewalRecord, 
  StockAdjustmentRecord, 
  StorageLocation,
  ItemCondition,
  StockAdjustmentType,
  UserRole,
  SystemUser
} from '../types/inventory';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api';
const TOKEN_KEY = 'msc_dfis_session_token';
const USER_KEY = 'msc_dfis_authenticated_user';

export interface ApiResponse<T = any> {
  success: boolean;
  message?: string;
  data?: T;
  [key: string]: any;
}

export interface DashboardData {
  total_units: number;
  available_units: number;
  issued_units: number;
  damaged_units: number;
  overdue_count: number;
  pending_renewals: number;
  systemDate: string;
  recentIssues?: IssueRecord[];
}

export class ApiError extends Error {
  status: number;
  data?: any;

  constructor(message: string, status: number, data?: any) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

class ApiService {
  private token: string | null = null;

  constructor() {
    this.token = localStorage.getItem(TOKEN_KEY);
  }

  setToken(token: string | null) {
    this.token = token;
    if (token) {
      localStorage.setItem(TOKEN_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
    }
  }

  getToken(): string | null {
    if (!this.token) {
      this.token = localStorage.getItem(TOKEN_KEY);
    }
    return this.token;
  }

  getSavedUser(): SystemUser | null {
    try {
      const data = localStorage.getItem(USER_KEY);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  }

  setSavedUser(user: SystemUser | null) {
    if (user) {
      localStorage.setItem(USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(USER_KEY);
    }
  }

  private async request<T = any>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${API_BASE_URL}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`;
    const headers = new Headers(options.headers || {});

    if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
      headers.set('Content-Type', 'application/json');
    }

    const currentToken = this.getToken();
    if (currentToken) {
      headers.set('Authorization', `Bearer ${currentToken}`);
      headers.set('X-Session-Token', currentToken);
    }

    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });

      const isJson = response.headers.get('content-type')?.includes('application/json');
      const responseData = isJson ? await response.json() : await response.text();

      if (!response.ok) {
        const errorMsg = (typeof responseData === 'object' && responseData !== null && responseData.message)
          ? responseData.message
          : `HTTP ${response.status}: ${response.statusText}`;
        throw new ApiError(errorMsg, response.status, responseData);
      }

      return responseData as T;
    } catch (err: any) {
      if (err instanceof ApiError) throw err;
      throw new ApiError(err.message || 'Network error connecting to Flask backend', 0);
    }
  }

  // --- 1. Authentication ---
  async login(params: { username?: string; password?: string; role?: UserRole; studentId?: string }): Promise<{
    success: boolean;
    token: string;
    user: SystemUser & { student?: Student };
    message?: string;
  }> {
    const res = await this.request<{
      success: boolean;
      token: string;
      user: SystemUser & { student?: Student };
      message?: string;
    }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(params),
    });

    if (res.token) {
      this.setToken(res.token);
      this.setSavedUser(res.user);
    }
    return res;
  }

  async getCurrentUser(): Promise<SystemUser | null> {
    try {
      const res = await this.request<{ success: boolean; user: SystemUser }>('/auth/me');
      if (res.user) {
        this.setSavedUser(res.user);
        return res.user;
      }
      return null;
    } catch {
      this.setToken(null);
      return null;
    }
  }

  async logout(): Promise<void> {
    try {
      await this.request('/auth/logout', { method: 'POST' });
    } finally {
      this.setToken(null);
    }
  }

  // --- 2. System Simulation Date & Database Reset ---
  async getSystemDate(): Promise<string> {
    const res = await this.request<{ systemDate: string }>('/system/date');
    return res.systemDate;
  }

  async setSystemDate(systemDate: string): Promise<string> {
    const res = await this.request<{ success: boolean; systemDate: string }>('/system/date', {
      method: 'POST',
      body: JSON.stringify({ systemDate }),
    });
    return res.systemDate;
  }

  async resetSystem(): Promise<ApiResponse> {
    return this.request<ApiResponse>('/system/reset', { method: 'POST' });
  }

  // --- 3. Dashboard Metrics ---
  async getDashboardSummary(): Promise<DashboardData> {
    return this.request<DashboardData>('/dashboard');
  }

  // --- 4. Inventory Items ---
  async getItems(): Promise<InventoryItem[]> {
    return this.request<InventoryItem[]>('/items');
  }

  async getItemById(id: string): Promise<InventoryItem> {
    return this.request<InventoryItem>(`/items/${id}`);
  }

  async saveItem(itemData: Partial<InventoryItem>): Promise<{ success: boolean; message: string; item?: InventoryItem }> {
    return this.request<{ success: boolean; message: string; item?: InventoryItem }>('/items', {
      method: 'POST',
      body: JSON.stringify(itemData),
    });
  }

  // --- 5. Students ---
  async getStudents(): Promise<Student[]> {
    return this.request<Student[]>('/students');
  }

  async getStudentById(id: string): Promise<Student & { issues?: IssueRecord[] }> {
    return this.request<Student & { issues?: IssueRecord[] }>(`/students/${id}`);
  }

  async saveStudent(studentData: Partial<Student>): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>('/students', {
      method: 'POST',
      body: JSON.stringify(studentData),
    });
  }

  // --- 6. Locations ---
  async getLocations(): Promise<StorageLocation[]> {
    return this.request<StorageLocation[]>('/locations');
  }

  // --- 7. Item Issue (Rules 1-5) ---
  async getIssues(params?: { student_id?: string; status?: string; overdue?: boolean }): Promise<IssueRecord[]> {
    const query = new URLSearchParams();
    if (params?.student_id) query.set('student_id', params.student_id);
    if (params?.status) query.set('status', params.status);
    if (params?.overdue) query.set('overdue', 'true');
    const qs = query.toString();
    return this.request<IssueRecord[]>(`/issues${qs ? `?${qs}` : ''}`);
  }

  async issueItem(params: {
    studentId: string;
    itemId: string;
    assetId?: string;
    quantity: number;
    purpose: string;
    issueDate?: string;
    issuingStaff?: string;
    notes?: string;
  }): Promise<{ success: boolean; message: string; issueRecord?: IssueRecord; issue_number?: string; due_date?: string }> {
    return this.request<{ success: boolean; message: string; issueRecord?: IssueRecord; issue_number?: string; due_date?: string }>('/issue', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  }

  // --- 8. Item Returns (Rules 9-11) ---
  async getReturns(): Promise<ReturnRecord[]> {
    return this.request<ReturnRecord[]>('/returns');
  }

  async recordReturn(params: {
    issueId: string;
    quantityReturned: number;
    returnDate?: string;
    conditionOnReturn?: ItemCondition;
    receivingStaff?: string;
    remarks?: string;
  }): Promise<{ success: boolean; message: string; is_partial?: boolean }> {
    return this.request<{ success: boolean; message: string; is_partial?: boolean }>('/return', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  }

  // --- 9. Renewals (Rules 6-8) ---
  async getRenewals(): Promise<RenewalRecord[]> {
    return this.request<RenewalRecord[]>('/renewals');
  }

  async requestRenewal(params: {
    issueId: string;
    studentId?: string;
    remarks: string;
  }): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>('/renew/request', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  }

  async reviewRenewal(params: {
    renewalId: string;
    approve: boolean;
    remarks?: string;
    approvingStaff?: string;
  }): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>('/renew/review', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  }

  // --- 10. Stock Adjustments (Rules 10 & 12) ---
  async getAdjustments(): Promise<StockAdjustmentRecord[]> {
    return this.request<StockAdjustmentRecord[]>('/stock-adjustments');
  }

  async adjustStock(params: {
    itemId: string;
    assetId?: string;
    adjustmentType: StockAdjustmentType;
    quantity: number;
    reason: string;
    responsibleUser?: string;
  }): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>('/stock-adjustments', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  }

  // --- 11. Student Portal Authorized Queries ---
  async getMyIssues(studentId?: string): Promise<IssueRecord[]> {
    const qs = studentId ? `?student_id=${encodeURIComponent(studentId)}` : '';
    return this.request<IssueRecord[]>(`/student/me/issues${qs}`);
  }

  async getMyRenewals(studentId?: string): Promise<RenewalRecord[]> {
    const qs = studentId ? `?student_id=${encodeURIComponent(studentId)}` : '';
    return this.request<RenewalRecord[]>(`/student/me/renewals${qs}`);
  }

  async getMyReturns(studentId?: string): Promise<ReturnRecord[]> {
    const qs = studentId ? `?student_id=${encodeURIComponent(studentId)}` : '';
    return this.request<ReturnRecord[]>(`/student/me/returns${qs}`);
  }
}

export const api = new ApiService();
