import { 
  InventoryItem, 
  Student, 
  IssueRecord, 
  ReturnRecord, 
  RenewalRecord, 
  StockAdjustmentRecord, 
  StorageLocation,
  ItemCondition,
  StockAdjustmentType
} from '../types/inventory';
import { api } from './api';

let cachedSystemDate = '2026-10-19';
let cachedItems: InventoryItem[] = [];
let cachedStudents: Student[] = [];
let cachedIssues: IssueRecord[] = [];
let cachedReturns: ReturnRecord[] = [];
let cachedRenewals: RenewalRecord[] = [];
let cachedAdjustments: StockAdjustmentRecord[] = [];
let cachedLocations: StorageLocation[] = [];
let isInitialized = false;

// Initialize in-memory cache from backend Flask API
export async function syncStoreWithBackend(): Promise<void> {
  try {
    const [date, items, students, issues, returns, renewals, adjs, locs] = await Promise.all([
      api.getSystemDate().catch(() => cachedSystemDate),
      api.getItems().catch(() => []),
      api.getStudents().catch(() => []),
      api.getIssues().catch(() => []),
      api.getReturns().catch(() => []),
      api.getRenewals().catch(() => []),
      api.getAdjustments().catch(() => []),
      api.getLocations().catch(() => []),
    ]);

    cachedSystemDate = date;
    cachedItems = items;
    cachedStudents = students;
    cachedIssues = issues;
    cachedReturns = returns;
    cachedRenewals = renewals;
    cachedAdjustments = adjs;
    cachedLocations = locs;
    isInitialized = true;

    window.dispatchEvent(new Event('inventory-store-updated'));
    window.dispatchEvent(new Event('inventory-system-date-changed'));
  } catch (err) {
    console.warn('[InventoryStore] Sync warning, will retry on user actions:', err);
  }
}

// Kick off initial sync immediately in browser
if (typeof window !== 'undefined') {
  syncStoreWithBackend();
}

export class InventoryStore {
  static isLoaded(): boolean {
    return isInitialized;
  }

  // System Date
  static getSystemDate(): string {
    return cachedSystemDate;
  }

  static async setSystemDateAsync(dateStr: string): Promise<string> {
    try {
      const res = await api.setSystemDate(dateStr);
      cachedSystemDate = res;
      window.dispatchEvent(new Event('inventory-system-date-changed'));
      window.dispatchEvent(new Event('inventory-store-updated'));
      await this.refresh();
      return res;
    } catch (e) {
      console.error('Failed to set system date on backend', e);
      cachedSystemDate = dateStr;
      window.dispatchEvent(new Event('inventory-system-date-changed'));
      return dateStr;
    }
  }

  static setSystemDate(dateStr: string): void {
    cachedSystemDate = dateStr;
    window.dispatchEvent(new Event('inventory-system-date-changed'));
    this.setSystemDateAsync(dateStr);
  }

  // Items
  static getItems(): InventoryItem[] {
    return cachedItems;
  }

  static getItemById(id: string): InventoryItem | undefined {
    return cachedItems.find(i => i.id === id);
  }

  // Students
  static getStudents(): Student[] {
    return cachedStudents;
  }

  static getStudentById(id: string): Student | undefined {
    return cachedStudents.find(s => s.id === id);
  }

  // Issues
  static getIssues(): IssueRecord[] {
    return cachedIssues;
  }

  // Returns
  static getReturns(): ReturnRecord[] {
    return cachedReturns;
  }

  // Renewals
  static getRenewals(): RenewalRecord[] {
    return cachedRenewals;
  }

  // Adjustments
  static getAdjustments(): StockAdjustmentRecord[] {
    return cachedAdjustments;
  }

  // Locations
  static getLocations(): StorageLocation[] {
    return cachedLocations;
  }

  // Reset database to pristine M.Sc. DFIS demonstration state
  static async resetToDefaultsAsync(): Promise<void> {
    await api.resetSystem();
    await syncStoreWithBackend();
  }

  static resetToDefaults(): void {
    this.resetToDefaultsAsync();
  }

  static async refresh(): Promise<void> {
    await syncStoreWithBackend();
  }

  // Core Business Action: Issue Item
  static async issueItemAsync(params: {
    studentId: string;
    itemId: string;
    assetId?: string;
    quantity: number;
    purpose: string;
    issueDate: string;
    issuingStaff: string;
    notes?: string;
  }): Promise<{ success: boolean; message: string; issueRecord?: IssueRecord }> {
    try {
      const res = await api.issueItem(params);
      await syncStoreWithBackend();
      return res;
    } catch (err: any) {
      return { success: false, message: err.message || 'Issue failed on backend' };
    }
  }

  static issueItem(params: {
    studentId: string;
    itemId: string;
    assetId?: string;
    quantity: number;
    purpose: string;
    issueDate: string;
    issuingStaff: string;
    notes?: string;
  }): { success: boolean; message: string; issueRecord?: IssueRecord } {
    // Fire async backend call
    this.issueItemAsync(params);
    return { success: true, message: 'Processing issue request with department server...' };
  }

  // Core Business Action: Record Return
  static async recordReturnAsync(params: {
    issueId: string;
    quantityReturned: number;
    returnDate: string;
    conditionOnReturn: ItemCondition;
    receivingStaff: string;
    remarks: string;
  }): Promise<{ success: boolean; message: string }> {
    try {
      const res = await api.recordReturn(params);
      await syncStoreWithBackend();
      return res;
    } catch (err: any) {
      return { success: false, message: err.message || 'Return failed on backend' };
    }
  }

  static recordReturn(params: {
    issueId: string;
    quantityReturned: number;
    returnDate: string;
    conditionOnReturn: ItemCondition;
    receivingStaff: string;
    remarks: string;
  }): { success: boolean; message: string } {
    this.recordReturnAsync(params);
    return { success: true, message: 'Processing return with department server...' };
  }

  // Core Business Action: Request Renewal (by Student)
  static async requestRenewalAsync(params: {
    issueId: string;
    studentId: string;
    remarks: string;
  }): Promise<{ success: boolean; message: string }> {
    try {
      const res = await api.requestRenewal(params);
      await syncStoreWithBackend();
      return res;
    } catch (err: any) {
      return { success: false, message: err.message || 'Renewal request failed on backend' };
    }
  }

  static requestRenewal(params: {
    issueId: string;
    studentId: string;
    remarks: string;
  }): { success: boolean; message: string } {
    this.requestRenewalAsync(params);
    return { success: true, message: 'Submitting renewal request to department server...' };
  }

  // Core Business Action: Review Renewal (by Coordinator)
  static async reviewRenewalAsync(params: {
    renewalId: string;
    approve: boolean;
    remarks: string;
    approvingStaff: string;
  }): Promise<{ success: boolean; message: string }> {
    try {
      const res = await api.reviewRenewal(params);
      await syncStoreWithBackend();
      return res;
    } catch (err: any) {
      return { success: false, message: err.message || 'Renewal review failed on backend' };
    }
  }

  static reviewRenewal(params: {
    renewalId: string;
    approve: boolean;
    remarks: string;
    approvingStaff: string;
  }): { success: boolean; message: string } {
    this.reviewRenewalAsync(params);
    return { success: true, message: 'Recording renewal decision on department server...' };
  }

  // Stock Adjustment
  static async adjustStockAsync(params: {
    itemId: string;
    assetId?: string;
    adjustmentType: StockAdjustmentType;
    quantity: number;
    reason: string;
    responsibleUser: string;
  }): Promise<{ success: boolean; message: string }> {
    try {
      const res = await api.adjustStock(params);
      await syncStoreWithBackend();
      return res;
    } catch (err: any) {
      return { success: false, message: err.message || 'Stock adjustment failed on backend' };
    }
  }

  static adjustStock(params: {
    itemId: string;
    assetId?: string;
    adjustmentType: StockAdjustmentType;
    quantity: number;
    reason: string;
    responsibleUser: string;
  }): { success: boolean; message: string } {
    this.adjustStockAsync(params);
    return { success: true, message: 'Recording stock adjustment on department server...' };
  }

  // Add / Edit Inventory item
  static async saveItemAsync(itemData: Partial<InventoryItem>): Promise<{ success: boolean; message: string; item?: InventoryItem }> {
    try {
      const res = await api.saveItem(itemData);
      await syncStoreWithBackend();
      return res;
    } catch (err: any) {
      return { success: false, message: err.message || 'Saving item failed on backend' };
    }
  }

  static saveItem(itemData: Partial<InventoryItem>): { success: boolean; message: string; item?: InventoryItem } {
    this.saveItemAsync(itemData);
    return { success: true, message: 'Saving inventory item to department server...' };
  }

  // Add / Edit Student
  static async saveStudentAsync(studentData: Partial<Student>): Promise<{ success: boolean; message: string }> {
    try {
      const res = await api.saveStudent(studentData);
      await syncStoreWithBackend();
      return res;
    } catch (err: any) {
      return { success: false, message: err.message || 'Saving student failed on backend' };
    }
  }

  static saveStudent(studentData: Partial<Student>): { success: boolean; message: string } {
    this.saveStudentAsync(studentData);
    return { success: true, message: 'Registering student on department server...' };
  }
}
