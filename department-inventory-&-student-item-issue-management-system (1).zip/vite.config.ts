import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import http from 'http';
import { spawn } from 'child_process';
import { defineConfig, Plugin } from 'vite';

function flaskBackendPlugin(): Plugin {
  let flaskChild: any = null;

  return {
    name: 'flask-backend-server',
    configureServer() {
      // Check if Flask is already responding on port 5000
      const checkReq = http.get('http://127.0.0.1:5000/api/dashboard', () => {
        console.log('[Flask Plugin] Backend already running on port 5000.');
      });

      checkReq.on('error', () => {
        console.log('[Flask Plugin] Launching Python Flask backend on port 5000...');
        flaskChild = spawn('python3', [path.resolve(__dirname, 'backend_flask/app.py')], {
          stdio: 'inherit',
          detached: false,
        });

        flaskChild.on('error', (err: any) => {
          console.error('[Flask Plugin] Error starting Flask process:', err);
        });
      });

      const cleanup = () => {
        if (flaskChild) {
          try {
            flaskChild.kill();
          } catch (e) {}
          flaskChild = null;
        }
      };

      process.on('exit', cleanup);
      process.on('SIGINT', cleanup);
      process.on('SIGTERM', cleanup);
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), flaskBackendPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
      proxy: {
        '/api': {
          target: 'http://127.0.0.1:5000',
          changeOrigin: true,
          secure: false,
        },
      },
    },
  };
});
